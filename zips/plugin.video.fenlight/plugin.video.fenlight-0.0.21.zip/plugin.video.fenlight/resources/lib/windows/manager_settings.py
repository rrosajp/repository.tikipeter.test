# -*- coding: utf-8 -*-
from windows.base_window import BaseDialog
from caches.settings_cache import set_string, set_path
# from modules.kodi_utils import logger

class ManagerSettings(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)

	def run(self):
		self.doModal()
		self.clearProperties()

class ManagerFolderSources(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.main_menu = 2001
		self.settings_menu_id = 2101
		self.current_menu_id = 1
		self.make_main_menu_list()
		self.make_settings_list(1, reset=False)

	def onInit(self):
		self.add_items(self.main_menu, self.main_menu_list)
		self.add_items(self.settings_menu_id, self.settings_list)
		self.setFocusId(self.main_menu)

	def onAction(self, action):
		if action in self.closing_actions: return self.close()
		if self.getFocusId() == self.main_menu:
			main_menu_id = self.get_listitem(self.main_menu).getProperty('id')
			if main_menu_id == self.current_menu_id: return
			self.current_menu_id = main_menu_id
			self.make_settings_list(self.current_menu_id)
		else:
			if action in self.selection_actions:
				position = self.get_position(self.settings_menu_id)
				chosen_listitem = self.get_listitem(self.settings_menu_id)
				setting_mode = chosen_listitem.getProperty('setting_mode')
				setting_id = chosen_listitem.getProperty('setting_id')
				if setting_mode == 'set_string': set_string({'setting_id': setting_id})
				else: set_path({'setting_id': setting_id})
				self.make_settings_list(self.current_menu_id)
				self.select_item(self.settings_menu_id, position)

	def run(self):
		self.doModal()
		self.clearProperties()

	def make_main_menu_list(self):
		def builder():
			for item in [('folder 1', '1'), ('folder 2', '2'), ('folder 3', '3'), ('folder 4', '4'), ('folder 5', '5')]:
				listitem = self.make_listitem()
				listitem.setProperty('name', item[0])
				listitem.setProperty('id', item[1])
				yield listitem
		self.main_menu_list = list(builder())

	def make_settings_list(self, _id, reset=True):
		def builder():
			for item in settings:
				listitem = self.make_listitem()
				listitem.setProperty('name', item[0])
				listitem.setProperty('setting_value', item[1])
				listitem.setProperty('setting_mode', item[2]['setting_mode'])
				listitem.setProperty('setting_id', item[2]['setting_id'])
				yield listitem
		settings = [('Display Name', self.get_home_property('folder%s.display_name' % _id), {'setting_mode': 'set_string', 'setting_id': 'folder%s.display_name' % _id}),
				('Movies Directory', self.get_home_property('folder%s.movies_directory' % _id), {'setting_mode': 'set_path', 'setting_id': 'folder%s.movies_directory' % _id}),
				('TV Shows Directory', self.get_home_property('folder%s.tv_shows_directory' % _id), {'setting_mode': 'set_path', 'setting_id': 'folder%s.tv_shows_directory' % _id})]
		action_base = 'plugin://plugin.video.fenlight/?mode=settings_manager.%s'
		self.settings_list = list(builder())
		if reset:
			self.reset_window(self.settings_menu_id)
			self.add_items(self.settings_menu_id, self.settings_list)
