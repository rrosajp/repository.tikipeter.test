# -*- coding: utf-8 -*-
from caches.settings_cache import default_setting_values
from modules import kodi_utils
logger = kodi_utils.logger

json, ls, numeric_input = kodi_utils.json, kodi_utils.local_string, kodi_utils.numeric_input
get_setting, set_setting, get_property = kodi_utils.get_setting, kodi_utils.set_setting, kodi_utils.get_property
dialog, ok_dialog, select_dialog, confirm_dialog = kodi_utils.dialog, kodi_utils.ok_dialog, kodi_utils.select_dialog, kodi_utils.confirm_dialog

boolean_dict = {'true': 'false', 'false': 'true'}

def set_boolean(params):
	logger('params', params)
	setting = params['setting_id']
	set_setting(setting, boolean_dict[get_setting('fenlight.%s' % setting)])

def set_string(params):
	new_value = dialog.input('')
	if not new_value and not confirm_dialog(text='Enter Blank Value?', ok_label='Yes', cancel_label='Re-Enter Value', default_control=11): return set_string(params)
	set_setting(params['setting_id'], new_value)

def set_numeric(params):
	setting_id = params['setting_id']
	setting_values = default_setting_values(setting_id)
	values_get = setting_values.get
	min_value, max_value = int(values_get('min_value', '0')), int(values_get('max_value', '1000000'))
	negative_included = any((n < 0 for n in [min_value, max_value]))
	new_value = dialog.input('Range [B]%s - %s[/B].' % (min_value, max_value), type=numeric_input)
	if not new_value: return
	if negative_included and not new_value == '0':
		multiplier_values = [('Positive(+)', 1), ('Negative(-)', -1)]
		list_items = [{'line1': ls(item[0])} for item in multiplier_values]
		kwargs = {'items': json.dumps(list_items), 'narrow_window': 'true'}
		multiplier = select_dialog(multiplier_values, **kwargs)
		if multiplier: new_value = str(int(float(new_value) * multiplier[1]))
	if int(new_value) < min_value or int(new_value) > max_value:
		ok_dialog(text='Please Choose Between the Range [B]%s - %s[/B].' % (min_value, max_value))
		return set_numeric(params)
	set_setting(setting_id, new_value)

def set_path(params):
	setting_id = params['setting_id']
	setting_values = default_setting_values(setting_id)
	browse_mode = int(setting_values['browse_mode'])
	current_value = get_setting('fenlight.%s' % setting_id)
	new_value = dialog.browse(browse_mode, '', '', defaultt=current_value)
	if not new_value: return
	set_setting(setting_id, new_value)

def set_from_list(params):
	setting_id = params['setting_id']
	setting_values = default_setting_values(setting_id)
	settings_list = setting_values['choices']
	settings_list = [(v, k) for k, v in settings_list.items()]
	list_items = [{'line1': ls(item[0])} for item in settings_list]
	kwargs = {'items': json.dumps(list_items), 'narrow_window': 'true'}
	new_value = select_dialog(settings_list, **kwargs)
	if new_value:
		setting_value = new_value[1]
		set_setting(setting_id, setting_value)
