# -*- coding: utf-8 -*-

years_movies = [
2023, 2022, 2021, 2020, 2019, 2018, 2017, 2016, 2015, 2014, 2013, 2012, 2011, 2010, 2009, 2008, 2007, 2006, 2005, 2004, 2003, 2002, 2001, 2000, 1999, 1998, 1997, 1996, 1995,
1994, 1993, 1992, 1991, 1990, 1989, 1988, 1987, 1986, 1985, 1984, 1983, 1982, 1981, 1980, 1979, 1978, 1977, 1976, 1975, 1974, 1973, 1972, 1971, 1970, 1969, 1968, 1967, 1966,
1965, 1964, 1963, 1962, 1961, 1960, 1959, 1958, 1957, 1956, 1955, 1954, 1953, 1952, 1951, 1950, 1949, 1948, 1947, 1946, 1945, 1944, 1943, 1942, 1941, 1940, 1939, 1938, 1937,
1936, 1935, 1934, 1933, 1932, 1931, 1930, 1929, 1928, 1927, 1926, 1925, 1924, 1923, 1922, 1921, 1920, 1919, 1918, 1917, 1916, 1915, 1914, 1913, 1912, 1911, 1910, 1909, 1908,
1907, 1906, 1905, 1904, 1903, 1902, 1901, 1900
	]

years_tvshows = [
2023, 2022, 2021, 2020, 2019, 2018, 2017, 2016, 2015, 2014, 2013, 2012, 2011, 2010, 2009, 2008, 2007, 2006, 2005, 2004, 2003, 2002, 2001, 2000, 1999, 1998, 1997, 1996, 1995,
1994, 1993, 1992, 1991, 1990, 1989, 1988, 1987, 1986, 1985, 1984, 1983, 1982, 1981, 1980, 1979, 1978, 1977, 1976, 1975, 1974, 1973, 1972, 1971, 1970, 1969, 1968, 1967, 1966,
1965, 1964, 1963, 1962, 1961, 1960, 1959, 1958, 1957, 1956, 1955, 1954, 1953, 1952, 1951, 1950, 1949, 1948, 1947, 1946, 1945, 1944, 1943, 1942
	]

decades_movies = [
2020, 2010, 2000, 1990, 1980, 1970, 1960, 1950, 1940, 1930, 1920, 1910, 1900
	]

decades_tvshows = [
2020, 2010, 2000, 1990, 1980, 1970, 1960, 1950, 1940
	]

oscar_winners = (
{'results': [{'id': 545611}, {'id': 776503}, {'id': 581734}, {'id': 496243}, {'id': 490132}, {'id': 399055}, {'id': 376867}, {'id': 314365}, {'id': 194662}, {'id': 76203}, 
		{'id': 68734}, {'id': 74643}, {'id': 45269}, {'id': 12162}, {'id': 12405}, {'id': 6977}, {'id': 1422}, {'id': 1640}, {'id': 70}, {'id': 122}], 'total_pages': 5, 'page': 1},
{'results': [{'id': 1574}, {'id': 453}, {'id': 98}, {'id': 14}, {'id': 1934}, {'id': 597}, {'id': 409}, {'id': 197}, {'id': 13}, {'id': 424}, {'id': 33}, {'id': 274},
		{'id': 581}, {'id': 403}, {'id': 380}, {'id': 746}, {'id': 792}, {'id': 606}, {'id': 279}, {'id': 11050}], 'total_pages': 5, 'page': 2},
{'results': [{'id': 783}, {'id': 9443}, {'id': 16619}, {'id': 12102}, {'id': 11778}, {'id': 703}, {'id': 1366}, {'id': 510}, {'id': 240}, {'id': 9277}, {'id': 238},
		{'id': 1051}, {'id': 11202}, {'id': 3116}, {'id': 17917}, {'id': 10633}, {'id': 874}, {'id': 15121}, {'id': 11113}, {'id': 5769}], 'total_pages': 5, 'page': 3},
{'results': [{'id': 947}, {'id': 1725}, {'id': 284}, {'id': 665}, {'id': 17281}, {'id': 826}, {'id': 2897}, {'id': 15919}, {'id': 654}, {'id': 11426}, {'id': 27191},
		{'id': 2769}, {'id': 705}, {'id': 25430}, {'id': 23383}, {'id': 33667}, {'id': 887}, {'id': 28580}, {'id': 17661}, {'id': 27367}], 'total_pages': 5, 'page': 4},
{'results': [{'id': 289}, {'id': 43266}, {'id': 223}, {'id': 770}, {'id': 34106}, {'id': 43278}, {'id': 43277}, {'id': 12311}, {'id': 3078}, {'id': 56164}, {'id': 33680},
		{'id': 42861}, {'id': 143}, {'id': 65203}, {'id': 28966}, {'id': 631}], 'total_pages': 5, 'page': 5}

			)

movie_certifications = [
'G', 'PG', 'PG-13', 'R', 'NC-17', 'NR'
	]

tvshow_certifications = [
'tv-y', 'tv-y7', 'tv-g', 'tv-pg', 'tv-14', 'tv-ma'
	]

languages = [
('Arabic', 'ar'),         ('Bosnian', 'bs'),      ('Bulgarian', 'bg'),     ('Chinese', 'zh'),     ('Croatian', 'hr'),        ('Dutch', 'nl'),          ('English', 'en'),
('Finnish', 'fi'),        ('French', 'fr'),       ('German', 'de'),        ('Greek', 'el'),       ('Hebrew', 'he'),          ('Hindi', 'hi'),          ('Hungarian', 'hu'),
('Icelandic', 'is'),      ('Italian', 'it'),      ('Japanese', 'ja'),      ('Korean', 'ko'),      ('Macedonian', 'mk'),      ('Norwegian', 'no'),      ('Persian', 'fa'),
('Polish', 'pl'),         ('Portuguese', 'pt'),   ('Punjabi', 'pa'),       ('Romanian', 'ro'),    ('Russian', 'ru'),         ('Serbian', 'sr'),        ('Slovenian', 'sl'),
('Spanish', 'es'),        ('Swedish', 'sv'),      ('Turkish', 'tr'),       ('Ukrainian', 'uk')
	]

meta_languages = [
{'iso': 'zh', 'name': 'Chinese'},           {'iso': 'hr', 'name': 'Croatian'},          {'iso': 'cs', 'name': 'Czech'},             {'iso': 'da', 'name': 'Danish'},
{'iso': 'nl', 'name': 'Dutch'},             {'iso': 'en', 'name': 'English'},           {'iso': 'fi', 'name': 'Finnish'},           {'iso': 'fr', 'name': 'French'},
{'iso': 'de', 'name': 'German'},            {'iso': 'el', 'name': 'Greek'},             {'iso': 'he', 'name': 'Hebrew'},            {'iso': 'hu', 'name': 'Hungarian'},
{'iso': 'it', 'name': 'Italian'},           {'iso': 'ja', 'name': 'Japanese'},          {'iso': 'ko', 'name': 'Korean'},            {'iso': 'no', 'name': 'Norwegian'},
{'iso': 'pl', 'name': 'Polish'},            {'iso': 'pt', 'name': 'Portuguese'},        {'iso': 'ru', 'name': 'Russian'},           {'iso': 'sl', 'name': 'Slovenian'},
{'iso': 'es', 'name': 'Spanish'},           {'iso': 'sv', 'name': 'Swedish'},           {'iso': 'tr', 'name': 'Turkish'},           {'iso': 'ar-SA', 'name': 'Arabic Saudi Arabia'}
	]

language_choices =  {
'None': 'None',              'Afrikaans': 'afr',            'Albanian': 'alb',             'Arabic': 'ara',
'Armenian': 'arm',           'Basque': 'baq',               'Bengali': 'ben',              'Bosnian': 'bos',
'Breton': 'bre',             'Bulgarian': 'bul',            'Burmese': 'bur',              'Catalan': 'cat',
'Chinese': 'chi',            'Croatian': 'hrv',             'Czech': 'cze',                'Danish': 'dan',
'Dutch': 'dut',              'English': 'eng',              'Esperanto': 'epo',            'Estonian': 'est',
'Finnish': 'fin',            'French': 'fre',               'Galician': 'glg',             'Georgian': 'geo',
'German': 'ger',             'Greek': 'ell',                'Hebrew': 'heb',               'Hindi': 'hin',
'Hungarian': 'hun',          'Icelandic': 'ice',            'Indonesian': 'ind',           'Italian': 'ita',
'Japanese': 'jpn',           'Kazakh': 'kaz',               'Khmer': 'khm',                'Korean': 'kor',
'Latvian': 'lav',            'Lithuanian': 'lit',           'Luxembourgish': 'ltz',        'Macedonian': 'mac',
'Malay': 'may',              'Malayalam': 'mal',            'Manipuri': 'mni',             'Mongolian': 'mon',
'Montenegrin': 'mne',        'Norwegian': 'nor',            'Occitan': 'oci',              'Persian': 'per',
'Polish': 'pol',             'Portuguese': 'por',           'Portuguese(Brazil)': 'pob',   'Romanian': 'rum',
'Russian': 'rus',            'Serbian': 'scc',              'Sinhalese': 'sin',            'Slovak': 'slo',
'Slovenian': 'slv',          'Spanish': 'spa',              'Swahili': 'swa',              'Swedish': 'swe',
'Syriac': 'syr',             'Tagalog': 'tgl',              'Tamil': 'tam',                'Telugu': 'tel',
'Thai': 'tha',               'Turkish': 'tur',              'Ukrainian': 'ukr',            'Urdu': 'urd',
'Vietnamese': 'vie'
	}

regions = [
{'code': 'AF', 'name': 'Afghanistan'},          {'code': 'AL', 'name': 'Albania'},             {'code': 'DZ', 'name': 'Algeria'},       {'code': 'AQ', 'name': 'Antarctica'},
{'code': 'AR', 'name': 'Argentina'},            {'code': 'AM', 'name': 'Armenia'},             {'code': 'AU', 'name': 'Australia'},     {'code': 'AT', 'name': 'Austria'},
{'code': 'BD', 'name': 'Bangladesh'},           {'code': 'BY', 'name': 'Belarus'},             {'code': 'BE', 'name': 'Belgium'},       {'code': 'BR', 'name': 'Brazil'},
{'code': 'BG', 'name': 'Bulgaria'},             {'code': 'KH', 'name': 'Cambodia'},            {'code': 'CA', 'name': 'Canada'},        {'code': 'CL', 'name': 'Chile'},
{'code': 'CN', 'name': 'China'},                {'code': 'HR', 'name': 'Croatia'},             {'code': 'CZ', 'name': 'Czech Rep'},     {'code': 'DK', 'name': 'Denmark'},
{'code': 'EG', 'name': 'Germany'},              {'code': 'FI', 'name': 'France'},              {'code': 'FR', 'name': 'Finland'},       {'code': 'DE', 'name': 'Egypt'},
{'code': 'GR', 'name': 'Greece'},               {'code': 'HK', 'name': 'Hong Kong'},           {'code': 'HU', 'name': 'Hungary'},       {'code': 'IS', 'name': 'Iceland'},
{'code': 'IN', 'name': 'India'},                {'code': 'ID', 'name': 'Indonesia'},           {'code': 'IR', 'name': 'Iran'},          {'code': 'IQ', 'name': 'Iraq'},
{'code': 'IE', 'name': 'Ireland'},              {'code': 'IL', 'name': 'Israel'},              {'code': 'IT', 'name': 'Italy'},         {'code': 'JP', 'name': 'Japan'},
{'code': 'MY', 'name': 'Malaysia'},             {'code': 'NP', 'name': 'Nepal'},               {'code': 'NL', 'name': 'Netherlands'},   {'code': 'NZ', 'name': 'New Zealand'},
{'code': 'NO', 'name': 'Norway'},               {'code': 'PK', 'name': 'Pakistan'},            {'code': 'PY', 'name': 'Paraguay'},      {'code': 'PE', 'name': 'Peru'},
{'code': 'PH', 'name': 'Philippines'},          {'code': 'PL', 'name': 'Poland'},              {'code': 'PT', 'name': 'Portugal'},      {'code': 'PR', 'name': 'Puerto Rico'},
{'code': 'RO', 'name': 'Romania'},              {'code': 'RU', 'name': 'Russian Federation'},  {'code': 'SA', 'name': 'Saudi Arabia'},  {'code': 'RS', 'name': 'Serbia'},
{'code': 'SG', 'name': 'Singapore'},            {'code': 'SK', 'name': 'Slovakia'},            {'code': 'SI', 'name': 'Slovenia'},      {'code': 'ZA', 'name': 'South Africa'},
{'code': 'ES', 'name': 'Spain'},                {'code': 'LK', 'name': 'Sri Lanka'},           {'code': 'SE', 'name': 'Sweden'},        {'code': 'CH', 'name': 'Switzerland'},
{'code': 'TH', 'name': 'Thailand'},             {'code': 'TR', 'name': 'Turkey'},              {'code': 'UA', 'name': 'Ukraine'},       {'code': 'AE', 'name': 'United Arab Emirates'},
{'code': 'GB', 'name': 'United Kingdom'},       {'code': 'US', 'name': 'United States'},       {'code': 'UY', 'name': 'Uruguay'},       {'code': 'VE', 'name': 'Venezuela'},
{'code': 'VN', 'name': 'Viet Nam'},             {'code': 'YE', 'name': 'Yemen'},               {'code': 'ZW', 'name': 'Zimbabwe'}
	]

movie_genres = {
'Action': ['28', 'genre_action'], 'Adventure': ['12', 'genre_adventure'], 'Animation': ['16', 'genre_animation'], 'Comedy': ['35', 'genre_comedy'],
'Crime': ['80', 'genre_crime'], 'Documentary': ['99', 'genre_documentary'], 'Drama': ['18', 'genre_drama'], 'Family': ['10751', 'genre_family'],
'Fantasy': ['14', 'genre_fantasy'], 'History': ['36', 'genre_history'], 'Horror': ['27', 'genre_horror'], 'Music': ['10402', 'genre_music'],
'Mystery': ['9648', 'genre_mystery'], 'Romance': ['10749', 'genre_romance'], 'Science Fiction': ['878', 'genre_scifi'], 'TV Movie': ['10770', 'genre_soap'],
'Thriller': ['53', 'genre_thriller'], 'War': ['10752', 'genre_war'],  'Western': ['37', 'genre_western']
	}

tvshow_genres = {
'Action & Adventure': ['10759', 'genre_action'], 'Animation': ['16', 'genre_animation'], 'Comedy': ['35', 'genre_comedy'], 'Crime': ['80', 'genre_crime'],
'Documentary': ['99', 'genre_documentary'], 'Drama': ['18', 'genre_drama'], 'Family': ['10751', 'genre_family'], 'Kids': ['10762', 'genre_kids'],
'Mystery': ['9648', 'genre_mystery'], 'News':['10763', 'genre_news'], 'Reality': ['10764', 'genre_reality'], 'Sci-Fi & Fantasy': ['10765', 'genre_scifi'],
'Soap': ['10766', 'genre_soap'], 'Talk': ['10767', 'genre_talk'], 'War & Politics': ['10768', 'genre_war'], 'Western': ['37', 'genre_western']
	}

# tvshow_genres = {
# 'Action': ['action', 'genre_action'], 'Adventure': ['adventure', 'genre_adventure'], 'Animation': ['animation', 'genre_animation'], 'Anime': ['anime', 'genre_anime'],
# 'Children': ['children', 'genre_kids'], 'Comedy': ['comedy', 'genre_comedy'], 'Crime': ['crime', 'genre_crime'],
# 'Documentary': ['documentary', 'genre_documentary'], 'Drama': ['drama', 'genre_drama'], 'Family': ['family', 'genre_family'], 'Fantasy': ['fantasy', 'genre_fantasy'],
# 'Game Show': ['game-show', 'genre_talk'], 'History': ['history', 'genre_history'], 'Holiday': ['holiday', 'genre_foreign'], 'Horror': ['horror', 'genre_horror'],
# 'Music': ['music', 'genre_music'], 'Musical': ['musical', 'genre_music'], 'Mystery': ['mystery', 'genre_mystery'], 'News': ['news', 'genre_news'],
# 'Reality': ['reality', 'genre_reality'], 'Romance': ['romance', 'genre_romance'], 'Science Fiction': ['science-fiction', 'genre_scifi'], 'Soap': ['soap', 'genre_soap'],
# 'Superhero': ['superhero', 'genre_scifi'], 'Suspense': ['suspense', 'genre_thriller'], 'Talk Show': ['talk-show', 'genre_talk'], 'Thriller': ['thriller', 'genre_thriller'],
# 'War': ['war', 'genre_war'], 'Western': ['western', 'genre_western']
# 	}

networks = [
{'id': 54, 'name': 'Disney Channel', 'logo': 'network_disney'},                                  {'id': 44, 'name': 'Disney XD', 'logo': 'network_disneyxd'},
{'id': 2, 'name': 'ABC', 'logo': 'network_abc'},                                                 {'id': 493, 'name': 'BBC America', 'logo': 'network_bbcamerica'},
{'id': 6, 'name': 'NBC', 'logo': 'network_nbc'},                                                 {'id': 13, 'name': 'Nickelodeon', 'logo': 'network_nickelodeon'},
{'id': 14, 'name': 'PBS', 'logo': 'network_pbs'},                                                {'id': 16, 'name': 'CBS', 'logo': 'network_cbs'},
{'id': 19, 'name': 'FOX', 'logo': 'network_fox'},                                                {'id': 21, 'name': 'The WB', 'logo': 'network_thewb'},
{'id': 24, 'name': 'BET', 'logo': 'network_bet'},                                                {'id': 30, 'name': 'USA Network', 'logo': 'network_usanetwork'},
{'id': 23, 'name': 'CBC', 'logo': 'network_cbc'},                                                {'id': 88, 'name': 'FX', 'logo': 'network_fx'},
{'id': 33, 'name': 'MTV', 'logo': 'network_mtv'},                                                {'id': 34, 'name': 'Lifetime', 'logo': 'network_lifetime'},
{'id': 35, 'name': 'Nick Junior', 'logo': 'network_nickjr'},                                     {'id': 41, 'name': 'TNT', 'logo': 'network_tnt'},
{'id': 43, 'name': 'National Geographic', 'logo': 'network_natgeo'},                             {'id': 47, 'name': 'Comedy Central', 'logo': 'network_comedycentral'},
{'id': 49, 'name': 'HBO', 'logo': 'network_hbo'},                                                {'id': 55, 'name': 'Spike', 'logo': 'network_spike'},
{'id': 67, 'name': 'Showtime', 'logo': 'network_showtime'},                                      {'id': 56, 'name': 'Cartoon Network', 'logo': 'network_cartoonnetwork'},
{'id': 65, 'name': 'History Channel', 'logo': 'network_history'},                                {'id': 84, 'name': 'TLC', 'logo': 'network_tlc'},
{'id': 68, 'name': 'TBS', 'logo': 'network_tbs'},                                                {'id': 71, 'name': 'The CW', 'logo': 'network_thecw'},
{'id': 74, 'name': 'Bravo', 'logo': 'network_bravo'},                                            {'id': 76, 'name': 'E!', 'logo': 'network_e'},
{'id': 77, 'name': 'Syfy', 'logo': 'network_syfy'},                                              {'id': 80, 'name': 'Adult Swim', 'logo': 'network_adultswim'},
{'id': 91, 'name': 'Animal Planet', 'logo': 'network_animalplanet'},                             {'id': 110, 'name': 'CTV', 'logo': 'network_ctv'},
{'id': 129, 'name': 'A&E', 'logo': 'network_ane'},                                               {'id': 158, 'name': 'VH1', 'logo': 'network_vh1'},
{'id': 174, 'name': 'AMC', 'logo': 'network_amc'},                                               {'id': 928, 'name': 'Crackle', 'logo': 'network_crackle'},
{'id': 202, 'name': 'WGN America', 'logo': 'network_wgnamerica'},                                {'id': 209, 'name': 'Travel Channel', 'logo': 'network_travel'},
{'id': 213, 'name': 'Netflix', 'logo': 'network_netflix'},                                       {'id': 251, 'name': 'Audience', 'logo': 'network_audience'},
{'id': 270, 'name': 'SundanceTV', 'logo': 'network_sundancetv'},                                 {'id': 318, 'name': 'Starz', 'logo': 'network_starz'},
{'id': 359, 'name': 'Cinemax', 'logo': 'network_cinemax'},                                       {'id': 364, 'name': 'truTV', 'logo': 'network_trutv'},
{'id': 384, 'name': 'Hallmark Channel', 'logo': 'network_hallmark'},                             {'id': 397, 'name': 'TV Land', 'logo': 'network_tvland'},
{'id': 1024, 'name': 'Amazon', 'logo': 'network_amazon'},                                        {'id': 1267, 'name': 'Freeform', 'logo': 'network_freeform'},
{'id': 4, 'name': 'BBC 1', 'logo': 'network_bbc1'},                                              {'id': 332, 'name': 'BBC 2', 'logo': 'network_bbc2'},
{'id': 3, 'name': 'BBC 3', 'logo': 'network_bbc3'},                                              {'id': 100, 'name': 'BBC 4', 'logo': 'network_bbc4'},
{'id': 214, 'name': 'Sky 1', 'logo': 'network_sky1'},                                            {'id': 9, 'name': 'ITV', 'logo': 'network_itv'},
{'id': 26, 'name': 'Channel 4', 'logo': 'network_channel4'},                                     {'id': 99, 'name': 'Channel 5', 'logo': 'network_channel5'},
{'id': 136, 'name': 'E4', 'logo': 'network_e4'},                                                 {'id': 210, 'name': 'HGTV', 'logo': 'network_hgtv'},
{'id': 453, 'name': 'Hulu', 'logo': 'network_hulu'},                                             {'id': 1436, 'name': 'YouTube Red', 'logo': 'network_youtubered'},
{'id': 64, 'name': 'Discovery Channel', 'logo': 'network_discovery'},                            {'id': 2739, 'name': 'Disney+', 'logo': 'network_disneyplus'},
{'id': 2552, 'name': 'Apple TV +', 'logo': 'network_appletvplus'},                               {'id': 2697, 'name': 'Acorn TV', 'logo': 'network_acorntv'},
{'id': 1709, 'name': 'CBS All Access', 'logo': 'network_cbsallaccess'},                          {'id': 3186, 'name': 'HBO Max', 'logo': 'network_hbomax'},
{'id': 2243, 'name': 'DC Universe', 'logo': 'network_dcuniverse'},                               {'id': 2076, 'name': 'Paramount Network', 'logo': 'network_paramount'},
{'id': 4330, 'name': 'Paramount+', 'logo': 'network_paramountplus'},                             {'id': 3353, 'name': 'Peacock', 'logo': 'network_peacock'},
{'id': 4353, 'name': 'Discovery+', 'logo': 'network_discoveryplus'},                             {'id': 132, 'name': 'Oxygen', 'logo': 'network_oxygen'},
{'id': 244, 'name': 'Discovery ID', 'logo': 'network_discoveryid'}
	]

watch_providers = [
{'name': 'Netflix', 'id': 8, 'logo': 't2yyOv40HZeVlLjYsCsPHnWLk4W.jpg'},                     {'name': 'Amazon Prime Video', 'id': 9, 'logo': 'emthp39XA2YScoYL1p0sdbAH2WA.jpg'},
{'name': 'Disney Plus', 'id': 337, 'logo': '7rwgEs15tFwyR9NPQ5vpzxTj19Q.jpg'},               {'name': 'Google Play Movies', 'id': 3, 'logo': 'tbEdFQDwx5LEVr8WpSeXQSIirVq.jpg'},
{'name': 'Sun Nxt', 'id': 309, 'logo': 'uW4dPCcbXaaFTyfL5HwhuDt5akK.jpg'},                   {'name': 'Apple TV', 'id': 2, 'logo': 'peURlLlr8jggOwK53fJ5wdQl05y.jpg'},
{'name': 'MUBI', 'id': 11, 'logo': 'bVR4Z1LCHY7gidXAJF5pMa4QrDS.jpg'},                       {'name': 'Apple TV Plus', 'id': 350, 'logo': '6uhKBfmtzFqOcLousHwZuzcrScK.jpg'},
{'name': 'fuboTV', 'id': 257, 'logo': 'jPXksae158ukMLFhhlNvzsvaEyt.jpg'},                    {'name': 'Classix', 'id': 445, 'logo': 'iaMw6nOyxUzXSacrLQ0Au6CfZkc.jpg'},
{'name': 'Hulu', 'id': 15, 'logo': 'zxrVdFjIjLqkfnwyghnfywTn3Lh.jpg'},                       {'name': 'Curiosity Stream', 'id': 190, 'logo': '67Ee4E6qOkQGHeUTArdJ1qRxzR2.jpg'},
{'name': 'Paramount Plus', 'id': 531, 'logo': 'xbhHHa1YgtpwhC8lb1NQ3ACVcLd.jpg'},            {'name': 'GuideDoc', 'id': 100, 'logo': 'iX0pvJ2GFATbVIH5IHMwG0ffIdV.jpg'},
{'name': 'Public Domain Movies', 'id': 638, 'logo': 'liEIj6CkvojVDiMWeexGvflSPZT.jpg'},      {'name': 'HBO Max', 'id': 384, 'logo': 'Ajqyt5aNxNGjmF9uOfxArGrdf3X.jpg'},
{'name': 'Netflix Kids', 'id': 175, 'logo': 'j2OLGxyy0gKbPVI0DYFI2hJxP6y.jpg'},              {'name': 'Eventive', 'id': 677, 'logo': 'fadQYOyKL0tqfyj012nYJxm3N2I.jpg'},
{'name': 'Spamflix', 'id': 521, 'logo': 'xN97FFkFAdY1JvHhS4zyPD4URgD.jpg'},                  {'name': 'AMC+', 'id': 526, 'logo': 'xlonQMSmhtA2HHwK3JKF9ghx7M8.jpg'},
{'name': 'Cultpix', 'id': 692, 'logo': '59azlQKUgFdYq6QI5QEAxIeecyL.jpg'},                   {'name': 'DOCSVILLE', 'id': 475, 'logo': 'bvcdVO7SDHKEa6D40g1jntXKNj.jpg'},
{'name': 'Peacock', 'id': 386, 'logo': '8VCV78prwd9QzZnEm0ReO6bERDa.jpg'},                   {'name': 'VIX ', 'id': 457, 'logo': '58aUMVWJRolhWpi4aJCkGHwfKdg.jpg'},
{'name': 'FilmBox+', 'id': 701, 'logo': '4FqTBYsUSZgS9z9UGKgxSDBbtc8.jpg'},                  {'name': 'Peacock Premium', 'id': 387, 'logo': 'xTHltMrZPAJFLQ6qyCBjAnXSmZt.jpg'},
{'name': 'aha', 'id': 532, 'logo': 'm3NWxxR23l1w1e156fyTuw931gx.jpg'},                       {'name': 'Amazon Video', 'id': 10, 'logo': '5NyLm42TmCqCMOZFvH4fcoSNKEW.jpg'},
{'name': 'Kocowa', 'id': 464, 'logo': 'xfAAOAERZCnPB5jW5lhboAcXk8L.jpg'},                    {'name': 'WOW Presents Plus', 'id': 546, 'logo': 'mgD0T960hnYU4gBxbPPBrcDfgWg.jpg'},
{'name': 'Takflix', 'id': 1771, 'logo': 'cnIHBy3uLWhHRR7VeWQhK3ZsYP0.jpg'},                  {'name': 'Crunchyroll', 'id': 283, 'logo': '8Gt1iClBlzTeQs8WQm8UrCoIxnQ.jpg'},
{'name': 'YouTube', 'id': 192, 'logo': 'oIkQkEkwfmcG7IGpRR1NB8frZZM.jpg'},                   {'name': 'Magellan TV', 'id': 551, 'logo': 'gekkP93StjYdiMAInViVmrnldNY.jpg'},
{'name': 'BroadwayHD', 'id': 554, 'logo': 'xLu1rkZNOKuNnRNr70wySosfTBf.jpg'},                {'name': 'KoreaOnDemand', 'id': 575, 'logo': 'uHv6Y4YSsr4cj7q4cBbAg7WXKEI.jpg'},
{'name': 'Dekkoo', 'id': 444, 'logo': 'u2H29LCxRzjZVUoZUQAHKm5P8Zc.jpg'},                    {'name': 'Starz Apple TV', 'id': 1855, 'logo': 'hB24bAA8Y2ei6pbEGuCNdKUOjxI.jpg'},
{'name': 'Filmzie', 'id': 559, 'logo': 'olmH7t5tEng8Yuq33KmvpvaaVIg.jpg'},                   {'name': 'Showtime Apple TV', 'id': 675, 'logo': 'xVN3LKkOtCrlFT9mavhkx8SzMwV.jpg'},
{'name': 'True Story', 'id': 567, 'logo': 'osREemsc9uUB2J8VTkQeAVk2fu9.jpg'},                {'name': 'AMC Plus Apple TV ', 'id': 1854, 'logo': 'yFgm7vxwKZ4jfXIlPizlgoba2yi.jpg'},
{'name': 'DocAlliance Films', 'id': 569, 'logo': 'aQ1ritN00jXc7RAFfUoQKGAAfp7.jpg'},         {'name': 'Britbox Apple TV ', 'id': 1852, 'logo': 'cN85Wjk0FIFr3z6rbiimz10uWVo.jpg'},
{'name': 'Hoichoi', 'id': 315, 'logo': 'd4vHcXY9rwnr763wQns2XJThclt.jpg'},                   {'name': 'BritBox', 'id': 151, 'logo': 'aGIS8maihUm60A3moKYD9gfYHYT.jpg'},
{'name': 'Pluto TV', 'id': 300, 'logo': 't6N57S17sdXRXmZDAkaGP0NHNG0.jpg'},                  {'name': 'Starz', 'id': 43, 'logo': 'eWp5LdR4p4uKL0wACBBXapDV2lB.jpg'},
{'name': 'Rakuten Viki', 'id': 344, 'logo': 'qjtOUIUnk4kRpcZmaddjqDHM0dR.jpg'},              {'name': 'Discovery Plus Amazon', 'id': 584, 'logo': 'a2OcajC4bM5ItniQdjyOV7tgthW.jpg'},
{'name': 'iQIYI', 'id': 581, 'logo': '8MXYXzZGoPAEQU13GWk1GVvKNUS.jpg'},                     {'name': 'Showtime Amazon', 'id': 203, 'logo': 'zoL69abPHiVC1Qzd4kM6hwLSo0j.jpg'},
{'name': 'AMC+ Amazon', 'id': 528, 'logo': '9edKQczyuMmQM1yS520hgmJbcaC.jpg'},               {'name': 'Funimation Now', 'id': 269, 'logo': 'fWq61Fy4onav0wZJTA3c2fs0G66.jpg'},
{'name': 'The Roku Channel', 'id': 207, 'logo': 'z0h7mBHwm5KfMB2MKeoQDD2ngEZ.jpg'},          {'name': 'Showtime Roku Premium', 'id': 632, 'logo': 'qMf2zirM2w0sO0mdAIIoP5XnQn8.jpg'},
{'name': 'Runtime', 'id': 1875, 'logo': 'nvCfpn94VKJN4ZpkDgoupJWlXqq.jpg'},                  {'name': 'AMC+ Roku Premium', 'id': 635, 'logo': 'ni2NgPmIqqJRXeiA8Zdj4UhBZnU.jpg'},
{'name': 'YouTube Premium', 'id': 188, 'logo': '6IPjvnYl6WWkIwN158qBFXCr2Ne.jpg'},           {'name': 'YouTube Free', 'id': 235, 'logo': '4SCmZgf7AeJLKKRPcbf5VFkGpBj.jpg'},
{'name': 'Hoopla', 'id': 212, 'logo': 'aJ0b9BLU1Cvv5hIz9fEhKKc1x1D.jpg'},                    {'name': 'The CW', 'id': 83, 'logo': '6Y6w3F5mYoRHCcNAG0ZD2AndLJ2.jpg'},
{'name': 'Vudu', 'id': 7, 'logo': '21dEscfO8n1tL35k4DANixhffsR.jpg'},                        {'name': 'Starz Roku Premium', 'id': 634, 'logo': '5OAb2w7D9C2VHa0k5PaoAYeFYFE.jpg'},
{'name': 'VUDU Free', 'id': 332, 'logo': 'xzfVRl1CgJPYa9dOoyVI3TDSQo2.jpg'},                 {'name': 'Criterion Channel', 'id': 258, 'logo': '4TJTNWd2TT1kYj6ocUEsQc8WRgr.jpg'},
{'name': 'Showtime', 'id': 37, 'logo': '4kL33LoKd99YFIaSOoOPMQOSw1A.jpg'},                   {'name': 'PBS', 'id': 209, 'logo': 'bbxgdl6B5T75wJE713BiTCIBXyS.jpg'},
{'name': 'FXNow', 'id': 123, 'logo': 'twV9iQPYeaoBzwsfRFGMGoMIUg8.jpg'},                     {'name': 'Pantaflix', 'id': 177, 'logo': '2tAjxjo1n3H7fsXqMsxWFMeFUWp.jpg'},
{'name': 'Tubi TV', 'id': 73, 'logo': 'w2TDH9TRI7pltf5LjN3vXzs7QbN.jpg'},                    {'name': 'Kanopy', 'id': 191, 'logo': 'wbCleYwRFpUtWcNi7BLP3E1f6VI.jpg'},
{'name': 'Comedy Central', 'id': 243, 'logo': 'gmU9aPV3XUFusVs4kK1rcICUKqL.jpg'},            {'name': 'Microsoft Store', 'id': 68, 'logo': 'shq88b09gTBYC4hA7K7MUL8Q4zP.jpg'},
{'name': 'Redbox', 'id': 279, 'logo': 'gbyLHzl4eYP0oP9oJZ2oKbpkhND.jpg'},                    {'name': 'ABC', 'id': 148, 'logo': 'l9BRdAgQ3MkooOalsuu3yFQv2XP.jpg'},
{'name': 'Crackle', 'id': 12, 'logo': '7P2JHkfv4AmU2MgSPGaJ0z6nNLG.jpg'},                    {'name': 'DIRECTV', 'id': 358, 'logo': 'xL9SUR63qrEjFZAhtsipskeAMR7.jpg'},
{'name': 'Fandor', 'id': 25, 'logo': 'eAhAUvV2ouai3cGti5y70YOtrBN.jpg'},                     {'name': 'MGM Plus', 'id': 34, 'logo': '6A1gRIJqLfFHOoTvbTxDAbuU2nQ.jpg'},
{'name': 'Freeform', 'id': 211, 'logo': 'rgpmwMkXqFYch9cway9qWMw0uXu.jpg'},                  {'name': 'Syfy', 'id': 215, 'logo': 'f7iqKjWYdVoYVIvKP3nboULcrM2.jpg'},
{'name': 'Lifetime', 'id': 157, 'logo': '3wJNOOCbvqi7fJAdgf1QpL7Wwe2.jpg'},                  {'name': 'realeyz', 'id': 14, 'logo': '10BQc1kYmgjXFrFKb3xsRcDDn14.jpg'},
{'name': 'Shudder', 'id': 99, 'logo': 'pheENW1BxlexXX1CKJ4GyWudyMA.jpg'},                    {'name': 'Screambox', 'id': 185, 'logo': 'c2Ey5Q3uUjZgfWWQQIdVIjVfxE4.jpg'},
{'name': 'Acorn TV', 'id': 87, 'logo': '5P99DkK1jVs95KcE8bYG9MBtGQ.jpg'},                    {'name': 'Sundance Now', 'id': 143, 'logo': 'pZ9TSk3wlRYwiwwRxTsQJ7t2but.jpg'},
{'name': 'Popcornflix', 'id': 241, 'logo': 'olvOut34aWUFf1YoOqiqtjidiTK.jpg'},               {'name': 'Pantaya', 'id': 247, 'logo': '94IdHexespnJs96kmGiJlflfiwU.jpg'},
{'name': 'Boomerang', 'id': 248, 'logo': 'oRXiHzPl2HJMXXFR4eebsb8F5Oc.jpg'},                 {'name': 'Urban Movie Channel', 'id': 251, 'logo': '5uTsmZnDQmIOjZPEv8TNTy7GRJB.jpg'},
{'name': 'Dove Channel', 'id': 254, 'logo': 'cBCzPOX6ir5L8hCoJlfIWycxauh.jpg'},              {'name': 'History Vault', 'id': 268, 'logo': '3bm7P1O8WRqK6CYqfffJv4fba2p.jpg'},
{'name': 'Nickhits', 'id': 261, 'logo': 'oMwjMgYiT2jcR7ELqCH3TPzpgTX.jpg'},                  {'name': 'Eros Now', 'id': 218, 'logo': '4XYI2rzRm34skcvamytegQx7Dmu.jpg'},
{'name': 'Yupp TV', 'id': 255, 'logo': '8qNJcPBHZ4qewHrDJ7C7s2DBQ3V.jpg'},                   {'name': 'Magnolia Selects', 'id': 259, 'logo': 'foT1TtL67MgEOWR6Cib8dKyCvJI.jpg'},
{'name': 'WWE Network', 'id': 260, 'logo': 'rDYZ9v3Y09fuFyan51tHKE1mFId.jpg'},               {'name': 'Noggin', 'id': 262, 'logo': 'yxBUPUBFzHE72uFXvFr1l0fnMJA.jpg'},
{'name': 'Smithsonian Channel', 'id': 276, 'logo': 'UAZ2lJBWszijybQD4frqw2jxRO.jpg'},        {'name': 'Laugh Out Loud', 'id': 275, 'logo': 'w4GTJ1EDrgJku49XKSnRag9kKCT.jpg'},
{'name': 'Hallmark Movies', 'id': 281, 'logo': 'llEJ6av9kAniTQUR9hF9mhVbzlB.jpg'},           {'name': 'Pure Flix', 'id': 278, 'logo': 'orsVBNvPWxJNOVSEHMOk2h8R1wA.jpg'},
{'name': 'Lifetime Movie Club', 'id': 284, 'logo': 'p1v0UKH13xQsMjumRgCGmCdlgKm.jpg'},       {'name': 'Cinemax', 'id': 289, 'logo': 'kEnyHRflZPNWEOIXroZPhfdGi46.jpg'},
{'name': 'OVID', 'id': 433, 'logo': 'nXi2nRDPMNivJyFOifEa2t15Xuu.jpg'},                      {'name': 'Cohen Media Amazon', 'id': 1811, 'logo': 'jV7sSPzUYYHHmoATkD9PhFoEZXb.jpg'},
{'name': 'Viewster Amazon', 'id': 295, 'logo': 'mlH42JbZMrapSF6zc8iTYURcZlH.jpg'},           {'name': 'USA Network', 'id': 322, 'logo': 'ldU2RCgdvkcSEBWWbttCpVO450z.jpg'},
{'name': 'Sling TV Orange and Blue', 'id': 299, 'logo': 'tZ4xzOtCRHjAw7tYJphivEfDr1L.jpg'},  {'name': 'HiDive', 'id': 430, 'logo': '9baY98ZKyDaNArp1H9fAWqiR3Zi.jpg'},
{'name': 'Topic', 'id': 454, 'logo': 'ubWucXFn34TrVlJBaJFgPaC4tOP.jpg'},                     {'name': 'Night Flight Plus', 'id': 455, 'logo': 'ba8l0e5CkpVnrdFgzBySP7ckZnZ.jpg'},
{'name': 'Retrocrush', 'id': 446, 'logo': '9ONs8SMAXtkiyaEIKATTpbwckx8.jpg'},                {'name': 'Shout! Factory TV', 'id': 439, 'logo': 'ju3T8MFGNIoPiYpwHFpNlrYNyG7.jpg'},
{'name': 'Chai Flicks', 'id': 438, 'logo': '3tCqvc5hPm5nl8Hm8o2koDRZlPo.jpg'},               {'name': 'PBS Masterpiece Amazon', 'id': 294, 'logo': 'mMALQK52OFGoYUKOSCZILZkfGWs.jpg'},
{'name': 'The Film Detective', 'id': 470, 'logo': 'rOwEnT8oDSTZ5rDKmyaa3O4gUnc.jpg'},        {'name': 'MUBI Amazon', 'id': 201, 'logo': 'aJUiN18NZFbpSkHZQV1C1cTpz8H.jpg'},       
{'name': 'AcornTV Amazon', 'id': 196, 'logo': '8WWD7t5Irwq9kAH4rufQ4Pe1Dog.jpg'},            {'name': 'Screambox Amazon', 'id': 202, 'logo': 'naqM14qSfg2q0S2zDylM5zQQ3jn.jpg'},
{'name': 'Bet+ Amazon', 'id': 343, 'logo': 'obBJU4ak4XvAOUM5iVmSUxDvqC3.jpg'},               {'name': 'FlixFling', 'id': 331, 'logo': '4U02VrbgLfUKJAUCHKzxWFtnPx4.jpg'},
{'name': 'Darkmatter TV', 'id': 355, 'logo': 'x4AFz5koB2R8BRn8WNh6EqXUGHc.jpg'},             {'name': 'AMC on Demand', 'id': 352, 'logo': 'kJlVJLgbNPvKDYC0YMp3yA2OKq2.jpg'},
{'name': 'TCM', 'id': 361, 'logo': '8TbsXATKVD4Humjzi6a8SVaSY7o.jpg'},                       {'name': 'TNT', 'id': 363, 'logo': 'gJnQ40Z6T7HyY6fbmmI6qKE0zmK.jpg'},
{'name': 'BBC America', 'id': 397, 'logo': 'ukSXbR5qFjO2qCHpc6ZhcGPSjTJ.jpg'},               {'name': 'IndieFlix', 'id': 368, 'logo': '2NRn6OApVKfDTKLuHDRN8UadLRw.jpg'},
{'name': 'Here TV', 'id': 417, 'logo': 'sa10pK4Jwr5aA7rvafFP2zyLFjh.jpg'},                   {'name': 'Flix Premiere', 'id': 432, 'logo': '6fX0J6x7zXsUCvPFczgOW4oD34D.jpg'},
{'name': 'TBS', 'id': 506, 'logo': 'rcebVnRvZvPXauK4353Jgiu4DWI.jpg'},                       {'name': 'AsianCrush', 'id': 514, 'logo': '3VxDqUk25KU5860XxHKwV9cy3L8.jpg'},
{'name': 'FILMRISE', 'id': 471, 'logo': 'mEiBVz62M9j3TCebmOspMfqkIn.jpg'},                   {'name': 'Revry', 'id': 473, 'logo': 'r1UgUKmt83FSDOIHBdRWKooZPNx.jpg'},
{'name': 'Spectrum On Demand', 'id': 486, 'logo': '79mRAYq40lcYiXkQm6N7YErSSHd.jpg'},        {'name': 'VRV', 'id': 504, 'logo': 'rtTqPKRrVVXxvPV0T9OmSXhwXnY.jpg'},
{'name': 'Hi-YAH', 'id': 503, 'logo': 'mB2eDIncwSAlyl8WAtfV24qEIkk.jpg'},                    {'name': 'tru TV', 'id': 507, 'logo': 'pg4bIFyUsSIhFChqOz5Up1BxuIU.jpg'},
{'name': 'Discovery Plus', 'id': 520, 'logo': 'wYRiUqIgWcfUvO6OPcXuUNd4tc2.jpg'},            {'name': 'ARROW', 'id': 529, 'logo': '4UfmxLzph9Aso9pr9bXohp0V3sr.jpg'},
{'name': 'Plex', 'id': 538, 'logo': 'wDWvnupneMbY6RhBTHQC9zU0SCX.jpg'},                      {'name': 'Alamo on Demand', 'id': 547, 'logo': '1UP7ysjKolfD0rmp2fLmvyRHkdn.jpg'},
{'name': 'Dogwoof On Demand', 'id': 536, 'logo': '9sk88OAxDZSdMOzg8VuqtGpgWQ3.jpg'},         {'name': 'MovieSaints', 'id': 562, 'logo': 'fdWE8jpmQqkZrwg2ZMuCLz6ms5P.jpg'},
{'name': 'Film Movement Plus', 'id': 579, 'logo': 'tKJdVrC0fjEtQtYYjlVwX9rmqrj.jpg'},        {'name': 'Metrograph', 'id': 585, 'logo': '8PmpsrVDLJ3m8I37W6UNFEymhm7.jpg'},
{'name': 'Freevee', 'id': 613, 'logo': 'uBE4RMH15mrkuz6vXzuJc7ZLXp1.jpg'},                   {'name': 'Kino Now', 'id': 640, 'logo': 'ttxbDVmHMuNTKcSLOyIHFs7TdRh.jpg'},
{'name': 'ShortsTV Amazon', 'id': 688, 'logo': 'm0mvKlSjn38S9w7WVNV7a7XyPIe.jpg'},           {'name': 'Bet+', 'id': 1759, 'logo': 'eZVDDqlBHpuk8GELhQchRIkA6th.jpg'},
{'name': 'ESPN Plus', 'id': 1768, 'logo': 'iJBj5b4HYbjEPiwKJWQfcRr3nP2.jpg'},                {'name': 'Paramount+ Showtime', 'id': 1770, 'logo': 'vfUoancVnPRAxj8iBqhllanF0Eq.jpg'},
{'name': 'Klassiki', 'id': 1793, 'logo': 'fXGdolQR7QlHgdx2hPCxoVQG8eP.jpg'},                 {'name': 'Starz Amazon', 'id': 1794, 'logo': 'x36C6aseF5l4uX99Kpse9dbPwBo.jpg'},
{'name': 'Viaplay', 'id': 76, 'logo': 'cvl65OJnz14LUlC3yGK1KHj8UYs.jpg'},                    {'name': 'Popflick', 'id': 1832, 'logo': 'wbKHI2d5417yAAY7QestC3qnXyo.jpg'}
	]

color_palette = [
'FFFFFFE3', 'FFFFFAE6', 'FFFEF5E6', 'FFFEF0E5', 'FFFEEBE5', 'FFFFEFEF', 'FFFFE6EA', 'FFFFE6F1', 'FFFEE6F4', 'FFFFE6FB', 'FFFEE6FE', 'FFFAE6FF', 'FFF4E6FF', 'FFF0E6FF', 'FFEAE7FC',
'FFE6E7FC', 'FFE6EBFF', 'FFE7F0FF', 'FFE7F5FF', 'FFE7FAFF', 'FFE6FFFF', 'FFE6FFFB', 'FFE7FEF4', 'FFE7FFF1', 'FFE6FFEA', 'FFE7FFE7', 'FFEBFFF3', 'FFF1FFE6', 'FFF5FFE6', 'FFFBFFE6',
'FFFFFFFF', 'FFFFFFCB', 'FFFEFACA', 'FFFFEACB', 'FFFFE0CC', 'FFFED6CC', 'FFFFCACD', 'FFFFCCD5', 'FFFFCDE0', 'FFFFCCEB', 'FFFFCBF5', 'FFFECCFD', 'FFF6CBFF', 'FFECCCFE', 'FFE0CCFF',
'FFD6CCFE', 'FFCCCCFE', 'FFCDD6FF', 'FFCAE1FF', 'FFCCEBFF', 'FFCEF4FD', 'FFCAFFFF', 'FFCCFFF6', 'FFCBFEEB', 'FFCCFFE0', 'FFCCFFD6', 'FFCDFFCC', 'FFD7FFCB', 'FFE1FFCD', 'FFEBFFCC',
'FFF5FFCB', 'FFEFEFEF', 'FFFEFFB3', 'FFFFF1B2', 'FFFFE0B2', 'FFFDD2B2', 'FFFFC2B3', 'FFFFB3B3', 'FFFFB2C2', 'FFFFB3D1', 'FFFFB3E1', 'FFFFB2F4', 'FFFFB3FE', 'FFF0B3FF', 'FFE1B2FF',
'FFD2B3FF', 'FFC1B3FE', 'FFB4B3FF', 'FFB3C1FE', 'FFB2D1FF', 'FFB3E0FF', 'FFB2F0FF', 'FFB3FFFF', 'FFB3FFF0', 'FFB4FFE0', 'FFB3FFD1', 'FFB4FEC3', 'FFB3FFB4', 'FFC2FFB2', 'FFD1FFB4',
'FFE0FFB3', 'FFF1FFB4', 'FFE0E0E0', 'FFFEFF99', 'FFFFEB9A', 'FFFED699', 'FFFFC299', 'FFFFAD98', 'FFFF9899', 'FFFF99AE', 'FFFF99C1', 'FFFE99D5', 'FFFF99EC', 'FFFF99FF', 'FFEB99FF',
'FFD699FF', 'FFC299FF', 'FFAE99FF', 'FF9A99FF', 'FF98ADFE', 'FF9AC2FF', 'FF98D6FF', 'FF99EBFF', 'FF99FFFF', 'FF99FFEA', 'FF99FFD7', 'FF9AFFC3', 'FF99FFAC', 'FF99FF99', 'FFADFF99',
'FFC2FF98', 'FFD6FF99', 'FFEAFF98', 'FFD0D0D0', 'FFFFFF80', 'FFFFE681', 'FFFFCC80', 'FFFFB381', 'FFFF9980', 'FFFE8081', 'FFFF8199', 'FFFF80B3', 'FFFF80CD', 'FFFF80E7', 'FFFC81FE',
'FFE680FF', 'FFCC7FFF', 'FFB380FF', 'FF9980FF', 'FF807FFE', 'FF8099FE', 'FF7FB3FF', 'FF80CCFE', 'FF80E6FF', 'FF7FFFFE', 'FF7FFEE0', 'FF80FFCC', 'FF80FFB2', 'FF80FF98', 'FF81FF81',
'FF99FF80', 'FFB3FF80', 'FFCCFF80', 'FFE6FF80', 'FFC0C0C0', 'FFFFFF6B', 'FFFEE066', 'FFFFC267', 'FFFFA366', 'FFFF8566', 'FFFF6766', 'FFFF6685', 'FFFF66A4', 'FFFF66C1', 'FFFF66E0',
'FFFF66FF', 'FFE166FF', 'FFC366FF', 'FFA366FF', 'FF8566FF', 'FF6665FE', 'FF6785FF', 'FF66A3FE', 'FF65C2FF', 'FF65E0FF', 'FF65FFFF', 'FF66FFE0', 'FF65FFC1', 'FF66FFA4', 'FF65FF85',
'FF66FF66', 'FF84FF66', 'FFA2FF66', 'FFC2FF66', 'FFE0FF66', 'FFAFAFAF', 'FFFFFF4D', 'FFFFDB4E', 'FFFFB84E', 'FFFF944C', 'FFFF714D', 'FFFF4D4D', 'FFFF4D6F', 'FFFE4D93', 'FFFE4DB7',
'FFFE4DDB', 'FFFF4DFF', 'FFDC4DFF', 'FFB84DFF', 'FF944EFF', 'FF704DFF', 'FF4D4CFF', 'FF4D70FE', 'FF4D94FE', 'FF4DB8FF', 'FF4DDBFF', 'FF4DFFFF', 'FF4DFFDB', 'FF4EFFB9', 'FF4EFF95',
'FF4DFE70', 'FF4CFF4C', 'FF70FF4D', 'FF94FF4D', 'FFB8FE4D', 'FFDAFF4D', 'FF8C8C8C', 'FFFFFF33', 'FFFFD634', 'FFFFAD33', 'FFFF8532', 'FFFF5C33', 'FFFF3334', 'FFFF335C', 'FFFF3287',
'FFFF33AE', 'FFFF33D6', 'FFFE33FF', 'FFD633FE', 'FFAD34FF', 'FF8534FF', 'FF5D33FF', 'FF3233FF', 'FF325CFE', 'FF3285FF', 'FF33ADFF', 'FF33D6FF', 'FF33FFFE', 'FF32FFD6', 'FF34FFAD',
'FF33FF84', 'FF32FF5C', 'FF34FF33', 'FF5CFF34', 'FF85FE33', 'FFADFE33', 'FFD5FF33', 'FF7C7C7C', 'FFFFFF19', 'FFFFD119', 'FFFFA418', 'FFFF751A', 'FFFF4719', 'FFFF1919', 'FFFF1947',
'FFFF1874', 'FFFF19A3', 'FFFF19D1', 'FFFF19FF', 'FFD019FF', 'FFA219FF', 'FF751AFE', 'FF4719FF', 'FF1819FF', 'FF1947FF', 'FF1974FF', 'FF19A3FE', 'FF18D1FF', 'FF19FFFF', 'FF19FFD1',
'FF19FFA4', 'FF18FF75', 'FF19FF47', 'FF19FF19', 'FF48FF19', 'FF76FF19', 'FFA3FE1A', 'FFD1FF19', 'FF6B6B6B', 'FFFFFF00', 'FFFFCC00', 'FFFE9900', 'FFFF6600', 'FFFF3300', 'FFFE0000',
'FFFE0032', 'FFFF0066', 'FFFF0198', 'FFFF00CC', 'FFFF00FE', 'FFCC00FF', 'FF9A00FF', 'FF6601FF', 'FF3300FF', 'FF0000FE', 'FF0033FF', 'FF0166FF', 'FF0097FE', 'FF00CCFF', 'FF00FFFF',
'FF01FFCD', 'FF00FF99', 'FF00FE67', 'FF00FF33', 'FF00FF01', 'FF33FF00', 'FF65FF00', 'FF99FE00', 'FFCCFF00', 'FF5D5D5D', 'FFE8E500', 'FFE6B800', 'FFE68B00', 'FFE65C01', 'FFE72E00',
'FFE60000', 'FFE6002E', 'FFE6005B', 'FFE80183', 'FFE600B8', 'FFE600E6', 'FFB700E6', 'FF8900E6', 'FF5C01E5', 'FF2E00E6', 'FF0000E6', 'FF012EE1', 'FF005BE7', 'FF008AE5', 'FF00B8E6',
'FF00E6E6', 'FF00E6B7', 'FF00E78B', 'FF00E65F', 'FF00E532', 'FF00E600', 'FF2FE600', 'FF5DE600', 'FF8AE501', 'FFB8E600', 'FF4F4F4F', 'FFCDCC00', 'FFCDA301', 'FFCA7B02', 'FFCC5200',
'FFCC2900', 'FFCC0001', 'FFCD0029', 'FFCE0052', 'FFCC007B', 'FFCD00A3', 'FFCB00CC', 'FFA300CB', 'FF7A01CC', 'FF5201CC', 'FF2A00D0', 'FF0000CC', 'FF0029CB', 'FF0052CC', 'FF007ACD',
'FF00A3CC', 'FF00CCCB', 'FF00CCA3', 'FF01CC7A', 'FF03CB51', 'FF00CC29', 'FF01CC00', 'FF29CC01', 'FF52CB00', 'FF7ACB00', 'FFA2CC00', 'FF434343', 'FFB4B300', 'FFB38E00', 'FFB36B00',
'FFB34700', 'FFB32501', 'FFB30101', 'FFB40025', 'FFB40047', 'FFB4006B', 'FFB5008B', 'FFB300B3', 'FF8F00B2', 'FF6B00B2', 'FF4700B4', 'FF2300B2', 'FF0000B2', 'FF0025B4', 'FF0047B3',
'FF006BB3', 'FF008EB2', 'FF00B3B2', 'FF00B38E', 'FF00B36C', 'FF00B346', 'FF00B324', 'FF00B300', 'FF24B301', 'FF47B200', 'FF6CB201', 'FF90B301', 'FF373737', 'FF999A00', 'FF987A00',
'FF995C01', 'FF9A3D00', 'FF9A1F00', 'FF990100', 'FF99001F', 'FF9A003E', 'FF99005B', 'FF9A007A', 'FF990099', 'FF7B0099', 'FF5D0099', 'FF3D0099', 'FF1F0099', 'FF000098', 'FF011F99',
'FF003D98', 'FF005C99', 'FF007A99', 'FF009999', 'FF00997A', 'FF00995B', 'FF00993E', 'FF00991F', 'FF009900', 'FF1E9900', 'FF3C9900', 'FF5C9900', 'FF7A9900', 'FF2E2E2E', 'FF7F8000',
'FF7F6601', 'FF804C00', 'FF803201', 'FF801A01', 'FF800000', 'FF800019', 'FF800033', 'FF80004B', 'FF810065', 'FF81007F', 'FF660080', 'FF4C007F', 'FF33007F', 'FF1A0080', 'FF010080',
'FF011A7F', 'FF003480', 'FF004C80', 'FF00667F', 'FF008081', 'FF008067', 'FF037F4B', 'FF008033', 'FF00801B', 'FF008001', 'FF1A8000', 'FF338000', 'FF4C8001', 'FF668100', 'FF242424',
'FF656600', 'FF675201', 'FF653D00', 'FF672900', 'FF661400', 'FF660000', 'FF660015', 'FF660028', 'FF65003C', 'FF660053', 'FF660066', 'FF550069', 'FF3D0067', 'FF290066', 'FF150067',
'FF010066', 'FF001465', 'FF012966', 'FF003D66', 'FF005267', 'FF006766', 'FF006651', 'FF00663E', 'FF01662A', 'FF006613', 'FF006600', 'FF146600', 'FF296600', 'FF3D6600', 'FF516600',
'FF181818', 'FF4B4C00', 'FF4C3E01', 'FF4D2E00', 'FF4C1F00', 'FF4D0F00', 'FF4C0000', 'FF4C000F', 'FF4B001F', 'FF4C002E', 'FF4C003E', 'FF4C004B', 'FF3D004D', 'FF2E004B', 'FF1F004C',
'FF0E004B', 'FF01004C', 'FF000E4B', 'FF001F4D', 'FF012E4D', 'FF003D4C', 'FF004C4C', 'FF004D3D', 'FF004C2E', 'FF004C1E', 'FF004C0E', 'FF004C01', 'FF0F4C00', 'FF204C01', 'FF2D4C00',
'FF3E4C01', 'FF000000'
	]
