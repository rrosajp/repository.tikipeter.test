# -*- coding: utf-8 -*-
from windows.base_window import BaseDialog, json
# from modules.kodi_utils import logger

class DownloadsManager(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.window_id = 2500
		self.closed = False
		self.position = 0

	def onInit(self):
		self.make_active_downloads(first_run=True)
		self.monitor()

	def run(self):
		self.doModal()
		self.clearProperties()

	def onAction(self, action):
		if action in self.closing_actions:
			self.closed = True
			return self.close()
		else:
			if action in self.selection_actions:
				chosen_listitem = self.get_listitem(self.window_id)
				name = chosen_listitem.getProperty('name')

	def make_active_downloads(self, first_run=False):
		def builder():
			for item in self.active_downloads:
				try:
					listitem = self.make_listitem()
					listitem.setProperty('name', item.replace('.', ' ').replace('_', ' '))
					listitem.setProperty('percent', self.get_home_property(item))
					yield listitem
				except: pass
		try:
			self.active_downloads = json.loads(self.get_home_property('active_downloads') or '[]')
			self.item_list = list(builder())
			self.setProperty('active.number', 'Active Downloads: %s' % len(self.active_downloads))
			self.add_items(self.window_id, self.item_list)
			if first_run: self.setFocusId(self.window_id)
			else: self.select_item(self.window_id, self.position)
		except: pass

	def monitor(self):
		while not self.closed:
			if not self.active_downloads: break
			self.sleep(1000)
			self.position = self.position = self.get_position(self.window_id)
			self.reset_window(self.window_id)
			self.make_active_downloads()
