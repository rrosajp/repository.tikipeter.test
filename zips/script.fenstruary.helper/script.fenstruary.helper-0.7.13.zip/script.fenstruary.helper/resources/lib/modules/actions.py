# -*- coding: utf-8 -*-
import xbmc, xbmcgui
# from modules.logger import logger

window = xbmcgui.Window(10000)
get_infolabel = xbmc.getInfoLabel

def person_search(params):
	active_addon = get_infolabel('Skin.String(FenVariant)') or 'fen'
	mode = 'person_search_choice' if active_addon == 'fen' else 'person_data_dialog'
	return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.%s/?mode=%s&query=%s)' % (active_addon, mode, params['query']))

def extras(params):
	active_addon = get_infolabel('Skin.String(FenVariant)') or 'fen'
	extras_params = get_infolabel('ListItem.Property(%s.extras_params)' % active_addon)
	if extras_params: return xbmc.executebuiltin('RunPlugin(%s)' % extras_params)
	is_widget = xbmc.getInfoLabel('Container.PluginName') == ''
	db_type = xbmc.getInfoLabel('ListItem.DBType')
	media_type = 'movie' if db_type == 'movie' else 'tvshow' if db_type in ('tvshow', 'season', 'episode') else ''
	tmdb_id = xbmc.getInfoLabel('ListItem.UniqueId(tmdb)')
	if '' in (is_widget, media_type, tmdb_id): return
	return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.%s/?mode=extras_menu_choice&media_type=%s&tmdb_id=%s&is_widget=%s)' \
					% (active_addon, media_type, tmdb_id, is_widget))
