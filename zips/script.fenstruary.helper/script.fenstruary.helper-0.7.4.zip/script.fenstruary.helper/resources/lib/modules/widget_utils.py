# -*- coding: utf-8 -*-
import xbmc, xbmcgui
# from modules.logger import logger

def widget_monitor(list_id):
	if len(list_id) != 4: return
	monitor, window = xbmc.Monitor(), xbmcgui.Window(10000)
	window.clearProperty('fenstruary.last_path')
	try: delay = float(xbmc.getInfoLabel('Skin.String(category_widget_delay)')) / 1000
	except: delay = 0.75
	while list_id == str(window.getFocusId()) and not monitor.abortRequested():
		if xbmcgui.getCurrentWindowId() != 10000: return
		cpath_label, cpath_path = xbmc.getInfoLabel('ListItem.Label'), xbmc.getInfoLabel('ListItem.FolderPath')
		if switch_widgets(window, monitor, delay, cpath_path):
			window.setProperty('fenstruary.%s.label' % list_id, cpath_label)
			window.setProperty('fenstruary.%s.path' % list_id, cpath_path)
			window.setProperty('fenstruary.last_path', cpath_path)
			monitor.waitForAbort(0.75)
			try: window.getControl(int(list_id + '1')).selectItem(0)
			except: pass
		else: monitor.waitForAbort(0.75)
	try: del monitor
	except: pass
	try: del window
	except: pass

def switch_widgets(window, monitor, delay, cpath_path):
	cont = True
	total_pause = 0
	while total_pause < delay:
		monitor.waitForAbort(0.25)
		if xbmc.getInfoLabel('ListItem.FolderPath') != cpath_path or xbmcgui.getCurrentWindowId() != 10000:
			cont = False
			break
		if window.getProperty('fenstruary.last_path') == cpath_path or xbmc.getCondVisibility('System.HasActiveModalDialog'):
			cont = False
			break
		total_pause += 0.25
	return cont
