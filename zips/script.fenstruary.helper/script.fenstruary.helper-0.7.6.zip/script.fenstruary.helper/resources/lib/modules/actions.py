# -*- coding: utf-8 -*-
import xbmc, xbmcgui
# from modules.logger import logger

window = xbmcgui.Window(10000)
get_infolabel = xbmc.getInfoLabel

def person_search(params):
	return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.fen/?mode=person_search_choice&query=%s)' % params['query'])

def extras(params):
	return xbmc.executebuiltin('RunPlugin(%s)' % get_infolabel('ListItem.Property(fen.extras_params)'))
