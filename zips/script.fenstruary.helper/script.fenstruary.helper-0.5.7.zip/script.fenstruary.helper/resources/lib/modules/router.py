# -*- coding: utf-8 -*-
import sys
from urllib.parse import parse_qsl
# from modules.logger import logger

def routing():
	import xbmc
	params = dict(parse_qsl(sys.argv[1], keep_blank_values=True))
	_get = params.get
	mode = _get('mode', 'check_for_update')
	if mode == 'check_for_update':
		from modules.version_monitor import check_for_update
		check_for_update(_get('skin_id'))
	elif mode == 'manage_widgets':
		from modules.widget_maker import HomeWidgets
		HomeWidgets(_get('widget_setting')).manage_widgets()
	elif mode == 'manage_category_widget':
		from modules.widget_maker import HomeWidgets
		HomeWidgets(_get('widget_setting')).manage_category_widget()
	elif mode == 'manage_main_menu_path':
		from modules.widget_maker import HomeWidgets
		HomeWidgets(_get('widget_setting')).manage_main_menu_path()
	elif mode == 'remake_all_widgets':
		from modules.widget_maker import remake_all_widgets
		remake_all_widgets()
