# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcvfs
import json
import sqlite3 as database
from threading import Thread
from modules import xmls
# from modules.logger import logger

dialog = xbmcgui.Dialog()
window = xbmcgui.Window(10000)
max_widgets = 10

settings_path = xbmcvfs.translatePath('special://profile/addon_data/script.fenstruary.helper/')
database_path = xbmcvfs.translatePath('special://profile/addon_data/script.fenstruary.helper/widget_cache.db')
movies_xml, tvshows_xml = 'script-fenstruary-widget_movies', 'script-fenstruary-widget_tvshows'
movies_categories_xml, tvshows_categories_xml = 'script-fenstruary-widget_movie_category', 'script-fenstruary-widget_tvshow_category'
movies_main_menu_xml, tvshows_main_menu_xml = 'script-fenstruary-main_menu_movies', 'script-fenstruary-main_menu_tvshows'

class HomeWidgets:
	def __init__(self, widget_setting):
		self.widget_setting = widget_setting
		self.refresh_widgets = False
		self.last_widget = None
		self.connect_database()
		self.media_type = 'movie' if 'movie' in self.widget_setting else 'tvshow'
		self.widget_lookup = "'%s%s'" % (self.widget_setting, '%')
		self.set_main_include()

	def set_main_include(self):
		if 'category' in self.widget_setting: self.main_include = 'MovieCategoryWidget' if self.media_type == 'movie' else 'TVShowCategoryWidget'
		else: self.main_include = 'MovieWidgets' if self.media_type == 'movie' else 'TVShowWidgets'

	def connect_database(self):
		if not xbmcvfs.exists(settings_path): xbmcvfs.mkdir(settings_path)
		self.dbcon = database.connect(database_path, timeout=20)
		self.dbcon.execute("""CREATE TABLE IF NOT EXISTS widgets
					(widget_setting text unique, widget_path text, widget_header text, widget_type text, widget_setting_label text, widget_limit text)""")
		self.dbcur = self.dbcon.cursor()

	def add_widget_to_database(self, widget_setting, widget_path, widget_header, widget_type, widget_setting_label, widget_limit):
		self.refresh_widgets = True
		self.dbcur.execute("""INSERT OR REPLACE INTO widgets VALUES (?, ?, ?, ?, ?, ?)""",
							(widget_setting, widget_path, widget_header, widget_type, widget_setting_label, widget_limit))
		self.dbcon.commit()

	def remove_widget_from_database(self, widget_setting):
		self.refresh_widgets = True
		self.dbcur.execute('DELETE FROM widgets WHERE widget_setting = ?', (widget_setting,))
		self.dbcon.commit()

	def fetch_current_widgets(self):
		current_widgets = self.dbcur.execute(
			"""SELECT * FROM widgets WHERE widget_setting LIKE %s""" % self.widget_lookup).fetchall()
		try: current_widgets.sort(key=lambda k: k[0])
		except: pass
		return current_widgets

	def make_media_xml(self, active_widgets):
		if not self.refresh_widgets: return
		if not active_widgets: return
		if 'category' in active_widgets[0][0]:
			item = active_widgets[0]
			xml_file = 'special://skin/xml/%s.xml' % (movies_categories_xml if self.media_type == 'movie' else tvshows_categories_xml)
			list_id = '7009' if self.media_type == 'movie' else '8009'
			final_format = xmls.category_xml.format(main_include=self.main_include, widget_path=item[1], widget_header=item[2], widget_limit=item[5], widget_list_id=list_id)
			if not '&amp;' in final_format: final_format = final_format.replace('&', '&amp;')
		elif 'main_menu' in active_widgets[0][0]:
			item = active_widgets[0]
			xml_file = 'special://skin/xml/%s.xml' % (movies_main_menu_xml if self.media_type == 'movie' else tvshows_main_menu_xml)
			main_menu_xml = xmls.main_menu_movies_xml if self.media_type == 'movie' else xmls.main_menu_tvshows_xml
			final_format = main_menu_xml.format(main_menu_path=item[1])
			if not '&amp;' in final_format: final_format = final_format.replace('&', '&amp;')
		else:
			xml_file = 'special://skin/xml/%s.xml' % (movies_xml if self.media_type == 'movie' else tvshows_xml)
			list_id = 7010 if self.media_type == 'movie' else 8010
			final_format = xmls.media_xml_start.format(main_include=self.main_include)
			if not active_widgets: active_widgets = [('', '', '', 'WidgetListPoster', '', '')]
			for item in active_widgets:
				body = xmls.media_xml_body.format(widget_type=item[3], widget_path=item[1], widget_header=item[2], widget_limit=item[5], widget_list_id=list_id)
				if not '&amp;' in body: final_format += body.replace('&', '&amp;')
				list_id += 1
			final_format += xmls.media_xml_end
		with xbmcvfs.File(xml_file, 'w') as f: f.write(final_format)
		Thread(target=self.reload_skin).start()

	def manage_category_widget(self):
		widget_path, widget_header = self.widget_maker()
		if widget_path is None: return
		self.add_widget_to_database(self.widget_setting, widget_path, widget_header, '', '', '')
		self.make_media_xml([(self.widget_setting, widget_path, widget_header, '', '', '')])

	def manage_main_menu_path(self):
		widget_path = self.widget_maker()
		if not widget_path: return
		self.add_widget_to_database(self.widget_setting, widget_path, '', '', '', '')
		self.make_media_xml([(self.widget_setting, widget_path, '', '', '', '')])
	
	def reload_skin(self):
		if window.getProperty('fen.clear_path_refresh') == 'true': return
		window.setProperty('fen.clear_path_refresh', 'true')
		while xbmcgui.getCurrentWindowId() == 10035: xbmc.sleep(500)
		window.setProperty('fen.clear_path_refresh', '')
		xbmc.sleep(200)
		xbmc.executebuiltin('ReloadSkin()')

	def manage_widgets(self):
		active_widgets = self.fetch_current_widgets()
		len_current_widgets = len(active_widgets)
		display_widget_list = []
		display_widget_list_append = display_widget_list.append
		for count, item in enumerate(active_widgets, 1):
			widget_setting = item[0]
			name = 'Widget %s : %s' % (count, item[4])
			display_widget_list_append((name, widget_setting, True))
		len_display_widgets = len(display_widget_list)
		if len_display_widgets < max_widgets:
			widget_number = len_display_widgets + 1
			widget_setting = '%s.%s' % (self.widget_setting, widget_number)
			name = 'Widget %s :' % widget_number
			display_widget_list_append((name, widget_setting, False))
		hide_busy_dialog()
		choice = dialog.select('Choose Widget', [i[0] for i in display_widget_list])
		if choice == -1: return self.make_media_xml(active_widgets)
		self.chosen_widget = display_widget_list[choice]
		self.last_widget = self.chosen_widget[2]
		self.widget_maker()
		return self.manage_widgets()

	def clean_header(self, header):
		return header.replace('[B]', '').replace('[/B]', '').replace(' >>', '')

	def widget_maker(self, header=None, path=None):
		show_busy_dialog()
		if header: header = self.clean_header(header)
		if path: folders = [('Use [B]%s[/B] As Path' % header, 'set_path')]
		else:
			folders = [('Clear Current Path', 'clear_path')] if self.last_widget else []
			path = 'addons://sources/video'
		result = files_get_directory(path)
		if result:
			folders.extend([('%s >>' % i['label'], i['file']) for i in result if i['file'].startswith('plugin://') and i['filetype'] == 'directory'])
			hide_busy_dialog()
			choice = dialog.select('Choose Path', [i[0] for i in folders])
			if choice == -1:
				if 'main_menu' in self.widget_setting: return None
				else: return None, None
			choice = folders[choice]			
			if choice[1] == 'set_path':
				if 'main_menu' in self.widget_setting: return path
				header = dialog.input('Label', defaultt=header)
				if not header: return None, None
				if 'category' in self.widget_setting: return path, header
				types = (('Poster', 'WidgetListPoster'), ('Thumb', 'WidgetListEpisodes'))
				choice = dialog.select('Choose Type', [i[0] for i in types])
				if choice == -1: return
				_type = types[choice][1]
				label_type = types[choice][0]
				limit = dialog.input('Widget Limit (0 or blank for no limit))', type=1)
				limit_used = limit not in ('', '0', -1)
				setting_label = '%s | %s' % (header, label_type)
				if limit_used: setting_label += ' | x%s' % limit
				self.add_widget_to_database(self.chosen_widget[1], path, header, _type, setting_label, limit)
			elif choice[1] == 'clear_path':
				if 'category' in self.widget_setting or 'main_menu' in self.widget_setting: self.remove_widget_from_database(self.widget_setting)
				else: self.remove_widget_from_database(self.chosen_widget[1])
			else: return self.widget_maker(choice[0], choice[1])
		else: hide_busy_dialog()
		try: dialog.close()
		except: pass

	def remake_widgets(self):
		self.refresh_widgets = True
		self.make_media_xml(self.fetch_current_widgets())

def remake_all_widgets():
	for item in ('movie.widget', 'tvshow.widget', 'movie.category_widget', 'tvshow.category_widget', 'movie.main_menu', 'tvshow.main_menu'): HomeWidgets(item).remake_widgets()
	xbmcgui.Dialog().ok('Fenstruary', 'Menus and Widgets Remade')

def files_get_directory(directory, properties=['title', 'file', 'thumbnail']):
	command = {'jsonrpc': '2.0', 'id': 0, 'method': 'Files.GetDirectory', 'params': {'directory': directory, 'media': 'files', 'properties': properties}}
	result = get_jsonrpc(command)
	return result.get('files', None)

def get_jsonrpc(request):
	response = xbmc.executeJSONRPC(json.dumps(request))
	result = json.loads(response)
	return result.get('result', None)

def show_busy_dialog():
	return xbmc.executebuiltin('ActivateWindow(busydialognocancel)')

def hide_busy_dialog():
	xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
	xbmc.executebuiltin('Dialog.Close(busydialog)')