# -*- coding: utf-8 -*-
import xbmc, xbmcgui
# from modules.logger import logger

def widget_monitor(list_id):
	if len(list_id) != 4: return
	monitor, window = xbmc.Monitor(), xbmcgui.Window(10000)
	try: delay = float(xbmc.getInfoLabel('Skin.String(category_widget_delay)')) / 1000
	except: delay = 0.75
	display_delay = xbmc.getInfoLabel('Skin.HasSetting(category_widget_display_delay)') == 'True'
	stack_id = list_id + '1'
	stack_control = window.getControl(int(stack_id))
	stack_label_control = window.getControl(int(stack_id + '666'))
	while not monitor.abortRequested():
		monitor.waitForAbort(0.25)
		if list_id != str(window.getFocusId()): break
		if xbmcgui.getCurrentWindowId() != 10000: break
		last_path = window.getProperty('fenstruary.%s.path' % list_id)
		cpath_path = xbmc.getInfoLabel('ListItem.FolderPath')
		if last_path == cpath_path: continue
		if xbmc.getCondVisibility('System.HasActiveModalDialog'): continue
		switch_widget = True
		total_pause = 0
		while not monitor.abortRequested() and total_pause <= delay:
			monitor.waitForAbort(0.25)
			if list_id != str(window.getFocusId()): switch_widget = False; break
			if last_path == cpath_path: switch_widget = False; break
			if xbmc.getInfoLabel('ListItem.FolderPath') != cpath_path: switch_widget = False; break
			if xbmc.getCondVisibility('System.HasActiveModalDialog'): switch_widget = False; break
			if xbmcgui.getCurrentWindowId() != 10000: switch_widget = False; break
			total_pause += 0.25
			if display_delay: stack_label_control.setLabel('Load Delay [B]%0.2f[/B] Seconds' % (total_pause))
		if switch_widget:
			cpath_label = xbmc.getInfoLabel('ListItem.Label')
			if display_delay: stack_label_control.setLabel(cpath_label)
			window.setProperty('fenstruary.%s.label' % list_id, cpath_label)
			window.setProperty('fenstruary.%s.path' % list_id, cpath_path)
			monitor.waitForAbort(0.75)
			try: stack_control.selectItem(0)
			except: pass
		else:
			if display_delay: stack_label_control.setLabel(window.getProperty('fenstruary.%s.label' % list_id))
			monitor.waitForAbort(0.25)
	try: del monitor
	except: pass
	try: del window
	except: pass
