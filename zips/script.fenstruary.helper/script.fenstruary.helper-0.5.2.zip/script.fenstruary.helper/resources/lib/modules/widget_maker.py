# -*- coding: utf-8 -*-
import xbmc, xbmcgui
import json
from threading import Thread
# from modules.logger import logger

dialog = xbmcgui.Dialog()
window = xbmcgui.Window(10000)
max_widgets = 10

def widget_maker(skin_setting, library_type='video', info=('', None), widget_active=False):
	show_busy_dialog()
	label, directory = info[0].replace(' >>', '').replace('[B]', '').replace('[/B]', ''), info[1]
	if not directory:
		folders = [('Clear Current Path', 'clear_path')] if widget_active else []
		directory = 'addons://sources/video'if library_type.startswith('video') else 'addons://sources/audio'
	else: folders = [('Use [B]%s[/B] As Path' % label, 'set_folder_path')]
	result = files_get_directory(directory)
	if result:
		folders.extend([('%s >>' % i['label'], i['file']) for i in result if i['file'].startswith('plugin://') and i['filetype'] == 'directory'])
		hide_busy_dialog()
		choice = dialog.select('Choose Path', [i[0] for i in folders])
		if choice == -1: return
		choice = folders[choice]
		if choice[1] == 'set_folder_path':
			label = dialog.input('Widget Label', defaultt=label)
			if not label: return
			types = ('Poster', 'Thumb')
			choice = dialog.select('Choose Type', types)
			if choice == -1: return
			type_choice = types[choice]
			limit = dialog.input('Widget Limit (0 or blank for no limit))', type=1)
			limit_used = limit not in ('', '0', -1)
			setting_label = '%s | %s' % (label, type_choice)
			if limit_used:
				setting_label += ' | x%s' % limit
				xbmc.executebuiltin('Skin.SetString(%s.limit, %s)' % (skin_setting, limit))
			xbmc.executebuiltin('Skin.SetString(%s.setting_label, %s)' % (skin_setting, setting_label))
			xbmc.executebuiltin('Skin.SetString(%s.path, %s)' % (skin_setting, directory))
			xbmc.executebuiltin('Skin.SetString(%s.header, %s)' % (skin_setting, label))
			xbmc.executebuiltin('Skin.SetString(%s.type, %s)' % (skin_setting, type_choice))
		elif choice[1] == 'clear_path': clear_skin_settings(skin_setting)
		else: return widget_maker(skin_setting, library_type, choice)
	else: hide_busy_dialog()
	try: dialog.close()
	except: pass

def files_get_directory(directory, properties=['title', 'file', 'thumbnail']):
	command = {'jsonrpc': '2.0', 'id': 0, 'method': 'Files.GetDirectory', 'params': {'directory': directory, 'media': 'files', 'properties': properties}}
	result = get_jsonrpc(command)
	return result.get('files', None)

def get_jsonrpc(request):
	response = xbmc.executeJSONRPC(json.dumps(request))
	result = json.loads(response)
	return result.get('result', None)

def clear_skin_settings(skin_setting):
	xbmc.executebuiltin('Skin.Reset(%s.setting_label, %s)' % (skin_setting, ''))
	xbmc.executebuiltin('Skin.Reset(%s.path, %s)' % (skin_setting, ''))
	xbmc.executebuiltin('Skin.Reset(%s.header, %s)' % (skin_setting, ''))
	xbmc.executebuiltin('Skin.Reset(%s.type, %s)' % (skin_setting, ''))
	xbmc.executebuiltin('Skin.Reset(%s.limit, %s)' % (skin_setting, ''))
	Thread(target=reload_skin).start()

def manage_widgets(skin_setting, first_run=True):
	if not first_run: xbmc.sleep(100)
	all_widgets = []
	all_widgets_append = all_widgets.append
	label_setting = '%s%s.setting_label'
	for i in range(1, max_widgets+1):
		active = xbmc.getInfoLabel('Skin.String(%s%s.header)' % (skin_setting, i)) is not ''
		name = 'Widget %s : %s' % (i, xbmc.getInfoLabel('Skin.String(%s)' % label_setting % (skin_setting, i)))
		all_widgets_append((name, '%s%s' % (skin_setting, i), active))
	choice = dialog.select('Choose Widget', [i[0] for i in all_widgets])
	if choice == -1: return
	choice = all_widgets[choice]
	widget_maker(choice[1], widget_active=choice[2])
	return manage_widgets(skin_setting, first_run=False)

def reload_skin():
	if window.getProperty('fen.clear_path_refresh') == 'true': return
	window.setProperty('fen.clear_path_refresh', 'true')
	while xbmcgui.getCurrentWindowId() == 10035: xbmc.sleep(500)
	window.setProperty('fen.clear_path_refresh', '')
	xbmc.sleep(100)
	xbmc.executebuiltin('ReloadSkin()')

def show_busy_dialog():
	return xbmc.executebuiltin('ActivateWindow(busydialognocancel)')

def hide_busy_dialog():
	xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
	xbmc.executebuiltin('Dialog.Close(busydialog)')