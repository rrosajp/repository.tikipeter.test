# -*- coding: utf-8 -*-
import xbmc, xbmcgui
import json
from threading import Thread
# from modules.logger import logger

dialog = xbmcgui.Dialog()
window = xbmcgui.Window(10000)
max_widgets = 10

# movie_widget_start = '\
# <?xml version="1.0" encoding="UTF-8"?>\
# \n<includes>\
# \n    <include name="MovieWidgets">'

# movie_widget_end = '\
# \n    </include>\
# \n</includes>'

# movie_widget_body = '\
# \n        <include content="WidgetListMovies">\
# \n            <param name="content_path" value="$INFO[Skin.String({setting_var}.path)]"/>\
# \n            <param name="widget_header" value="$INFO[Skin.String({setting_var}.header)]"/>\
# \n            <param name="setting_id" value="{setting_var}.type"/>\
# \n            <param name="limit" value="$INFO[Skin.String({setting_var}.limit)]"/>\
# \n            <param name="widget_target" value="videos"/>\
# \n            <param name="list_id" value="{list_id}"/>\
# \n        </include>'


def widget_maker(skin_setting, library_type='video', info=('', None), widget_active=False):
	show_busy_dialog()
	header, path = info[0].replace(' >>', '').replace('[B]', '').replace('[/B]', ''), info[1]
	if not path:
		folders = [('Clear Current Path', 'clear_path')] if widget_active else []
		path = 'addons://sources/video'if library_type.startswith('video') else 'addons://sources/audio'
	else: folders = [('Use [B]%s[/B] As Path' % header, 'set_folder_path')]
	result = files_get_directory(path)
	if result:
		folders.extend([('%s >>' % i['label'], i['file']) for i in result if i['file'].startswith('plugin://') and i['filetype'] == 'directory'])
		hide_busy_dialog()
		choice = dialog.select('Choose Path', [i[0] for i in folders])
		if choice == -1: return
		choice = folders[choice]
		if choice[1] == 'set_folder_path':
			header = dialog.input('Widget Label', defaultt=header)
			if not header: return
			types = ('Poster', 'Thumb')
			choice = dialog.select('Choose Type', types)
			if choice == -1: return
			_type = types[choice]
			limit = dialog.input('Widget Limit (0 or blank for no limit))', type=1)
			limit_used = limit not in ('', '0', -1)
			setting_label = '%s | %s' % (header, _type)
			if limit_used:
				setting_label += ' | x%s' % limit
				xbmc.executebuiltin('Skin.SetString(%s.limit, %s)' % (skin_setting, limit))
			xbmc.executebuiltin('Skin.SetString(%s.setting_label, %s)' % (skin_setting, setting_label))
			xbmc.executebuiltin('Skin.SetString(%s.path, %s)' % (skin_setting, path))
			xbmc.executebuiltin('Skin.SetString(%s.header, %s)' % (skin_setting, header))
			xbmc.executebuiltin('Skin.SetString(%s.type, %s)' % (skin_setting, _type))
		elif choice[1] == 'clear_path': clear_skin_settings(skin_setting)
		else: return widget_maker(skin_setting, library_type, choice)
	else: hide_busy_dialog()
	try: dialog.close()
	except: pass

def test_make_xml(final_format):
	import xbmcvfs
	addon_skins_folder = 'special://skin/xml/Includes_MediaWidgets2.xml'
	with xbmcvfs.File(addon_skins_folder, 'w') as f:
		f.write(final_format)

def files_get_directory(directory, properties=['title', 'file', 'thumbnail']):
	command = {'jsonrpc': '2.0', 'id': 0, 'method': 'Files.GetDirectory', 'params': {'directory': directory, 'media': 'files', 'properties': properties}}
	result = get_jsonrpc(command)
	return result.get('files', None)

def get_jsonrpc(request):
	response = xbmc.executeJSONRPC(json.dumps(request))
	result = json.loads(response)
	return result.get('result', None)

def clear_skin_settings(skin_setting):
	xbmc.executebuiltin('Skin.Reset(%s.setting_label, %s)' % (skin_setting, ''))
	xbmc.executebuiltin('Skin.Reset(%s.path, %s)' % (skin_setting, ''))
	xbmc.executebuiltin('Skin.Reset(%s.header, %s)' % (skin_setting, ''))
	xbmc.executebuiltin('Skin.Reset(%s.type, %s)' % (skin_setting, ''))
	xbmc.executebuiltin('Skin.Reset(%s.limit, %s)' % (skin_setting, ''))
	Thread(target=reload_skin).start()

def manage_widgets(skin_setting, first_run=True):
	show_busy_dialog()
	if not first_run: xbmc.sleep(100)
	all_widgets = []
	all_widgets_append = all_widgets.append
	
	# test_list = []
	# test_list_append = test_list.append

	for i in range(1, max_widgets+1):
		setting_var = '%s%s' % (skin_setting, i)
		active = xbmc.getInfoLabel('Skin.String(%s.header)' % setting_var) != ''
		name = 'Widget %s : %s' % (i, xbmc.getInfoLabel('Skin.String(%s.setting_label)' % setting_var))
		all_widgets_append((name, setting_var, active))
		
		# if active: test_list_append(setting_var)
	
	hide_busy_dialog()
	
	# list_id = 7010
	# final_format = movie_widget_start
	# for item in test_list:
	# 	test = movie_widget_body.format(setting_var=item, list_id=list_id)
	# 	final_format += test
	# 	list_id += 1
	# final_format += movie_widget_end
	# test_make_xml(final_format)

	choice = dialog.select('Choose Widget', [i[0] for i in all_widgets])
	if choice == -1: return
	choice = all_widgets[choice]
	widget_maker(choice[1], widget_active=choice[2])
	return manage_widgets(skin_setting, first_run=False)

def reload_skin():
	if window.getProperty('fen.clear_path_refresh') == 'true': return
	window.setProperty('fen.clear_path_refresh', 'true')
	while xbmcgui.getCurrentWindowId() == 10035: xbmc.sleep(500)
	window.setProperty('fen.clear_path_refresh', '')
	xbmc.sleep(100)
	xbmc.executebuiltin('ReloadSkin()')

def show_busy_dialog():
	return xbmc.executebuiltin('ActivateWindow(busydialognocancel)')

def hide_busy_dialog():
	xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
	xbmc.executebuiltin('Dialog.Close(busydialog)')