# -*- coding: utf-8 -*-
import sys
from urllib.parse import parse_qsl
# from modules.logger import logger

def routing():
	import xbmc
	params = dict(parse_qsl(sys.argv[1], keep_blank_values=True))
	_get = params.get
	mode = _get('mode', 'widget_maker')
	if mode == 'widget_maker':
		from modules.widget_maker import widget_maker
		widget_maker(_get('skin_setting'))
	elif mode == 'manage_widgets':
		from modules.widget_maker import manage_widgets
		manage_widgets(_get('skin_setting'))
