# -*- coding: utf-8 -*-

media_xml_start = '\
<?xml version="1.0" encoding="UTF-8"?>\
\n<includes>\
\n    <include name="{main_include}">'

media_xml_end = '\
\n    </include>\
\n</includes>'

media_xml_body = '\
\n        <include content="{widget_type}">\
\n            <param name="content_path" value="{widget_path}"/>\
\n            <param name="widget_header" value="{widget_header}"/>\
\n            <param name="limit" value="{widget_limit}"/>\
\n            <param name="widget_target" value="videos"/>\
\n            <param name="list_id" value="{widget_list_id}"/>\
\n        </include>'


category_xml = '\
<?xml version="1.0" encoding="UTF-8"?>\
\n<includes>\
\n    <include name="{main_include}">\
\n        <include content="WidgetListCategories">\
\n            <param name="content_path" value="{widget_path}"/>\
\n            <param name="widget_header" value="{widget_header}"/>\
\n            <param name="widget_target" value="videos"/>\
\n            <param name="list_id" value="{list_id}"/>\
\n        </include>\
\n    </include>\
\n</includes>'