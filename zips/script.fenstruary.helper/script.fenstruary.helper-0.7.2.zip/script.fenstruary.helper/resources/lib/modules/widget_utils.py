# -*- coding: utf-8 -*-
from xbmcgui import Window
from xbmc import Monitor, getInfoLabel, getCondVisibility
# from modules.logger import logger

def widget_monitor():
	window = Window(10000)
	if not window.getProperty('fenstruary.widget_monitor_running') == 'true':
		window.setProperty('fenstruary.widget_monitor_running', 'true')
		monitor = Monitor()
		abort_requested, wait_for_abort = monitor.abortRequested, monitor.waitForAbort
		while window.getProperty('fenstruary.widget_monitor') == 'true' and not abort_requested():
			list_id = str(window.getFocusId())
			cpath_label, cpath_path = getInfoLabel('ListItem.Label'), getInfoLabel('ListItem.FolderPath')
			wait_for_abort(0.75)
			if getCondVisibility('System.HasActiveModalDialog'): continue
			if len(list_id) != 4 or list_id != str(window.getFocusId()) or getInfoLabel('ListItem.FolderPath') != cpath_path: continue
			window.setProperty('fenstruary.%s.label' % list_id, cpath_label)
			window.setProperty('fenstruary.%s.path' % list_id, cpath_path)
			try: window.getControl(int(list_id + '1')).selectItem(0)
			except: pass
		try: del monitor
		except: pass
		window.setProperty('fenstruary.widget_monitor_running', 'false')
	try: del window
	except: pass