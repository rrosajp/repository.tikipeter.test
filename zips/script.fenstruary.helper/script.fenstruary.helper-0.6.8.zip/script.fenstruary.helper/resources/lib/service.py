# -*- coding: utf-8 -*-
from modules import service_functions
from modules.logger import logger


logger('FenstruaryHelper', 'Service Starting')
service_functions.starting_widgets()
service_functions.widget_monitor()
logger('FenstruaryHelper', 'Service Finished')
