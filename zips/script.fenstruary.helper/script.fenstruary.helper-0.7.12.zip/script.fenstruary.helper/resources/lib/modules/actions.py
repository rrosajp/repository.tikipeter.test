# -*- coding: utf-8 -*-
import xbmc, xbmcgui
# from modules.logger import logger

window = xbmcgui.Window(10000)
get_infolabel = xbmc.getInfoLabel

def person_search(params):
	return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.fen/?mode=person_search_choice&query=%s)' % params['query'])

def extras(params):
	fen_extras_params = get_infolabel('ListItem.Property(fen.extras_params)')
	if fen_extras_params: return xbmc.executebuiltin('RunPlugin(%s)' % fen_extras_params)
	is_widget = xbmc.getInfoLabel('Container.PluginName') == ''
	db_type = xbmc.getInfoLabel('ListItem.DBType')
	media_type = 'movie' if db_type == 'movie' else 'tvshow' if db_type in ('tvshow', 'season', 'episode') else ''
	tmdb_id = xbmc.getInfoLabel('ListItem.UniqueId(tmdb)')
	if '' in (is_widget, media_type, tmdb_id): return
	return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.fen/?mode=extras_menu_choice&media_type=%s&tmdb_id=%s&is_widget=%s)' \
					% (media_type, tmdb_id, is_widget))
