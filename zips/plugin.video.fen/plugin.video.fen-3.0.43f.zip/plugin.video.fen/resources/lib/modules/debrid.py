# -*- coding: utf-8 -*-
import time
from caches.debrid_cache import debrid_cache
from apis.real_debrid_api import RealDebridAPI
from apis.premiumize_api import PremiumizeAPI
from apis.alldebrid_api import AllDebridAPI
from modules import kodi_utils
from modules.utils import make_thread_list
from modules.settings import display_sleep_time, enabled_debrids_check
# logger = kodi_utils.logger

sleep, show_busy_dialog, hide_busy_dialog, notification = kodi_utils.sleep, kodi_utils.show_busy_dialog, kodi_utils.hide_busy_dialog, kodi_utils.notification
monitor, Thread, get_setting, ls = kodi_utils.monitor, kodi_utils.Thread, kodi_utils.get_setting, kodi_utils.local_string
debrid_list = [('Real-Debrid', 'rd'), ('Premiumize.me', 'pm'), ('AllDebrid', 'ad')]
debrid_list_modules = [('Real-Debrid', RealDebridAPI), ('Premiumize.me', PremiumizeAPI), ('AllDebrid', AllDebridAPI)]
timeout = 20.0

def debrid_enabled():
	return [i[0] for i in debrid_list if enabled_debrids_check(i[1])]

def debrid_type_enabled(debrid_type, enabled_debrids):
	return [i[0] for i in debrid_list if i[0] in enabled_debrids and get_setting('%s.%s.enabled' % (i[1], debrid_type)) == 'true']

def debrid_valid_hosts(enabled_debrids):
	def _get_hosts(function):
		debrid_hosts_append(function().get_hosts())
	debrid_hosts = []
	debrid_hosts_append = debrid_hosts.append
	if enabled_debrids:
		threads = list(make_thread_list(_get_hosts, [i[1] for i in debrid_list_modules if i[0] in enabled_debrids]))
		[i.join() for i in threads]
	return debrid_hosts

def manual_add_magnet_to_cloud(params):
	show_busy_dialog()
	function = [i[1] for i in debrid_list_modules if i[0] == params['provider']][0]
	result = function().create_transfer(params['magnet_url'])
	function().clear_cache()
	hide_busy_dialog()
	if result == 'failed': notification(32490)
	else: notification(32576)

class DebridCheck:

	def __init__(self, torrent_sources, non_torrent_sources, background, debrid_enabled, progress_dialog=None):
		self.torrent_sources = torrent_sources
		self.non_torrent_sources = non_torrent_sources
		self.background = background
		self.debrid_enabled = debrid_enabled
		self.progress_dialog = progress_dialog
		self.main_threads = []
		self.rd_cached_hashes, self.pm_cached_hashes, self.ad_cached_hashes = [], [], []
		self.sources_total = self.sources_4k = self.sources_1080p = self.sources_720p = self.sources_sd = 0

	def run(self):
		self.hash_list = list(set([i['hash'] for i in self.torrent_sources]))
		self.sleep_time = display_sleep_time()
		self.cached_hashes = self._query_local_cache()
		main_threads_append = self.main_threads.append
		debrid_runners = {'Real-Debrid': self.RD_check, 'Premiumize.me': self.PM_check, 'AllDebrid': self.AD_check}
		for item in self.debrid_enabled: main_threads_append(Thread(target=debrid_runners[item], name=item))
		if self.main_threads:
			[i.start() for i in self.main_threads]
			if self.background: [i.join() for i in self.main_threads]
			else: self.debrid_check_dialog()
		return {'rd_cached_hashes': self.rd_cached_hashes, 'pm_cached_hashes': self.pm_cached_hashes, 'ad_cached_hashes': self.ad_cached_hashes}

	def cached_check(self, debrid):
		cached_list = [i[0] for i in self.cached_hashes if i[1] == debrid and i[2] == 'True']
		unchecked_list = [i for i in self.hash_list if not any([h for h in self.cached_hashes if h[0] == i and h[1] == debrid])]
		return cached_list, unchecked_list

	def RD_check(self):
		self.rd_cached_hashes, unchecked_hashes = self.cached_check('rd')
		if unchecked_hashes:
			rd_cache = RealDebridAPI().check_cache(unchecked_hashes)
			if not rd_cache: return
			cached_append = self.rd_cached_hashes.append
			process_list = []
			process_append = process_list.append
			try:
				for h in unchecked_hashes:
					cached = 'False'
					try:
						if h in rd_cache:
							info = rd_cache[h]
							if isinstance(info, dict) and len(info.get('rd')) > 0:
								cached_append(h)
								cached = 'True'
					except: pass
					process_append((h, cached))
			except:
				for i in unchecked_hashes: process_append((i, 'False'))
			self._add_to_local_cache(process_list, 'rd')
		self.process_quality_count([i for i in self.torrent_sources if i['hash'] in self.rd_cached_hashes])

	def PM_check(self):
		self.pm_cached_hashes, unchecked_hashes = self.cached_check('pm')
		if unchecked_hashes:
			pm_cache = PremiumizeAPI().check_cache(unchecked_hashes)
			if not pm_cache: return
			cached_append = self.pm_cached_hashes.append
			process_list = []
			process_append = process_list.append
			try:
				pm_cache = pm_cache['response']
				for c, h in enumerate(unchecked_hashes):
					cached = 'False'
					try:
						if pm_cache[c] is True:
							cached_append(h)
							cached = 'True'
					except: pass
					process_append((h, cached))
			except:
				for i in unchecked_hashes: process_append((i, 'False'))
			self._add_to_local_cache(process_list, 'pm')
		self.process_quality_count([i for i in self.torrent_sources if i['hash'] in self.pm_cached_hashes])

	def AD_check(self):
		self.ad_cached_hashes, unchecked_hashes = self.cached_check('ad')
		if unchecked_hashes:
			ad_cache = AllDebridAPI().check_cache(unchecked_hashes)
			if not ad_cache: return
			cached_append = self.ad_cached_hashes.append
			process_list = []
			process_append = process_list.append
			try:
				ad_cache = ad_cache['magnets']
				for i in ad_cache:
					cached = 'False'
					try:
						if i['instant'] == True:
							cached_append(i['hash'])
							cached = 'True'
					except: pass
					process_append((i['hash'], cached))
			except:
				for i in unchecked_hashes: process_append((i, 'False'))
			self._add_to_local_cache(process_list, 'ad')
		self.process_quality_count([i for i in self.torrent_sources if i['hash'] in self.ad_cached_hashes])

	def debrid_check_dialog(self):
		self.progress_dialog.reset_is_cancelled()
		start_time = time.time()
		if self.non_torrent_sources:
			self.process_quality_count(self.non_torrent_sources)
			self.progress_dialog.update_results_count(self.sources_sd, self.sources_720p, self.sources_1080p, self.sources_4k, self.sources_total, '', 0)
		else: self.progress_dialog.update_results_count(0, 0, 0, 0, 0, '', 0)
		while not self.progress_dialog.iscanceled() and not monitor.abortRequested():
			try:
				remaining_debrids = [x.getName() for x in self.main_threads if x.is_alive() is True]
				current_progress = max((time.time() - start_time), 0)
				line1 = '[CR]'.join(remaining_debrids).upper()
				percent = int((current_progress/float(timeout))*100)
				self.progress_dialog.update_results_count(self.sources_sd, self.sources_720p, self.sources_1080p, self.sources_4k, self.sources_total, line1, percent)
				sleep(self.sleep_time)
				if len(remaining_debrids) == 0: break
				if percent >= 100: break
			except: pass

	def _query_local_cache(self):
		return debrid_cache.get_many(self.hash_list) or []

	def _add_to_local_cache(self, hash_list, debrid):
		debrid_cache.set_many(hash_list, debrid)
	
	def process_quality_count(self, sources):
		for i in sources:
			quality = i['quality']
			if quality == '4K': self.sources_4k += 1
			elif quality == '1080p': self.sources_1080p += 1
			elif quality == '720p': self.sources_720p += 1
			else: self.sources_sd += 1
			self.sources_total += 1
