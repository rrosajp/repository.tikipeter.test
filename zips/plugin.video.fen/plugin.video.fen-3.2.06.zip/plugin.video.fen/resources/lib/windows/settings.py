# -*- coding: utf-8 -*-
from windows.base_window import BaseDialog
# from modules.kodi_utils import all_settings
# from modules.kodi_utils import logger

class Settings(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.setProperty('highlight_var', self.highlight_var(force=True))
		# self.set_properties()

	def onInit(self):
		pass

	def run(self):
		self.doModal()
		self.clearProperties()
	
	def onAction(self, action, controlID=None):
		if action in self.selection_actions: self.progress_display_toggle('true')
		elif action in self.closing_actions:self.close()

	# def set_properties(self):
	# 	for item in all_settings():
	# 		self.set_property()