# -*- coding: utf-8 -*-
from xml.dom.minidom import parseString as mdParse
from caches.main_cache import cache_object
from modules.kodi_utils import make_session
from modules.settings import omdb_api_key
from modules.kodi_utils import logger

EXPIRY_1_WEEK = 168
url = 'http://www.omdbapi.com/?apikey=%s&i=%s&tomatoes=True&r=xml'
cache_string = 'omdb_ratings_%s'
session = make_session('http://www.omdbapi.com/')

class OMDbAPI:
	def fetch_info(self, imdb_id):
		if not imdb_id: return {}
		self.api_key = omdb_api_key()
		if not self.api_key: return {}
		string = cache_string % imdb_id
		return cache_object(self.process_result, string, imdb_id, json=False, expiration=EXPIRY_1_WEEK)

	def process_result(self, imdb_id):
		data = {}
		try:
			try:
				result = session.get(url % (self.api_key, imdb_id)).text
				response_test = dict(mdParse(result).getElementsByTagName('root')[0].attributes.items())
				if not response_test.get('response', 'False') == 'True': return {}
			except: return {}
			result = dict(mdParse(result).getElementsByTagName('movie')[0].attributes.items())
			data = {'awards': result.get('awards', '').replace('N/A', ''),
					'metascore_rating': result.get('metascore', '').replace('N/A', ''),
					'imdb_rating': result.get('imdbRating', '').replace('N/A', ''),
					'imdb_votes':result.get('imdbVotes', '').replace('N/A', ''),
					'tomato_rating': result.get('tomatoRating', '').replace('N/A', ''),
					'tomatometer_rating': result.get('tomatoMeter', '').replace('N/A', ''),
					'tomatousermeter_rating': result.get('tomatoUserMeter', '').replace('N/A', ''),
					'tomatouser_rating':result.get('tomatoUserRating', '').replace('N/A', ''),
					'tomato_userreviews': result.get('tomatoUserReviews', '').replace('N/A', ''),
					'tomato_image': result.get('tomatoImage', '').replace('N/A', ''),
					'tomato_reviews': result.get('tomatoReviews', '').replace('N/A', ''),
					'tomato_fresh': result.get('tomatoFresh', '').replace('N/A', ''),
					'tomato_rotten': result.get('tomatoRotten', '').replace('N/A', ''),
					'tomato_consensus': result.get('tomatoConsensus', '').replace('N/A', '')
					}
		except: pass
		return data

fetch_info = OMDbAPI().fetch_info