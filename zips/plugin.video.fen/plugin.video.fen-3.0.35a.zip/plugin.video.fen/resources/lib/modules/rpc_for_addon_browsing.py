
from modules.kodi_utils import json, execute_JSON, dialog, execute_builtin, set_property
from modules.kodi_utils import logger

def get_plugin_path(library_type='video', info=(None, None)):
    label, directory = info[0], info[1]
    if not directory: folders, directory = [], 'addons://sources/video'if library_type.startswith('video') else 'addons://sources/audio'
    else: folders = [('[B].:. Use As Path .:.[/B]', 'set_folder_path')]
    result = files_get_directory(directory)
    if result:
        folders.extend([('%s >>' % i['label'], i['file']) for i in result if i['file'].startswith('plugin://')])
        choice = dialog.select('Choose Path', [i[0] for i in folders])
        if choice == -1: return None
        choice = folders[choice]
        if choice[1] == 'set_folder_path':
            # execute_builtin('Skin.SetString(movie.widget1.path, %s)' % directory)
            # execute_builtin('Skin.SetString(movie.widget1.header, Test)')
            set_property('movie.widget1.path', directory)
            set_property('movie.widget1.header', label.replace(' >>', ''))
            execute_builtin('ActivateWindow(Home)')
            execute_builtin('ReloadSkin()')
            return directory
        else: return get_plugin_path(library_type, choice)
    try: dialog.close()
    except: pass

def files_get_directory(directory, properties=['title', 'file', 'thumbnail']):
    command = {'jsonrpc': '2.0', 'id': 0, 'method': 'Files.GetDirectory', 'params': {'directory': directory, 'media': 'files', 'properties': properties}}
    result = get_jsonrpc(command)
    return result.get('files', None)

def get_jsonrpc(request):
    response = execute_JSON(json.dumps(request))
    result = json.loads(response)
    return result.get('result', None)
