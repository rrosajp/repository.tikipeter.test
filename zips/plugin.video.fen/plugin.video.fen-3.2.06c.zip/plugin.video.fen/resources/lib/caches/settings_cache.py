# -*- coding: utf-8 -*-
import xbmcgui, xbmcaddon, xbmcvfs
from os import path as osPath
import sqlite3 as database
# from modules.kodi_utils import database, settings_db, set_property, get_property

BASE_GET = 'SELECT setting_value from settings WHERE setting_id = ?'
GET_MANY = 'SELECT * FROM settings WHERE setting_value in (%s)'
GET_ALL = 'SELECT setting_id, setting_value FROM settings'
BASE_SET = 'UPDATE settings SET setting_value = ? WHERE setting_id = ?'
SET_MANY = 'INSERT OR REPLACE INTO settings VALUES (?, ?, ?, ?)'
CLEAR_SETTINGS = 'DELETE FROM settings'

__addon__ = xbmcaddon.Addon('plugin.video.fen')
userdata_path = xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
database_path_raw = osPath.join(userdata_path, 'databases')
settings_db = xbmcvfs.translatePath(osPath.join(database_path_raw, 'settings.db'))
window = xbmcgui.Window(10000)
set_property = window.setProperty
get_property = window.getProperty

class SettingsCache:
	def __init__(self):
		self._connect_database()
		self._set_PRAGMAS()

	def get(self, setting_id, default_value=''):
		# from modules.kodi_utils import logger
		# logger('being sent to GET', setting_id)
		# logger('being sent to GET', default_value)
		setting_value = self.get_memory_cache(setting_id)
		# setting_value = None
		if not setting_value:
			try:
				setting_value = self.dbcur.execute(BASE_GET, (setting_id,)).fetchone()[0]
				self.set_memory_cache(setting_id, setting_value)
			except:
				self.set(setting_id, default_value)
				setting_value = default_value
		return setting_value

	def get_many(self, settings_list):
		self.dbcur.execute(GET_MANY % (', '.join('?' for _ in settings_list)), settings_list)
		cache_data = self.dbcur.fetchall()

	def get_all(self):
		try: all_settings = self.dbcur.execute(GET_ALL).fetchall()
		except: all_settings = []
		return all_settings

	def set(self, setting_id, setting_value):
		from modules.kodi_utils import logger
		logger('SET setting_id', setting_id)
		logger('SET setting_value', setting_value)
		self.dbcur.execute('INSERT OR REPLACE INTO settings VALUES (?, ?, ?, ?)', (*self.setting_info(setting_id), setting_value))
		self.set_memory_cache(setting_id, setting_value)

	def set_many(self, settings_list):
		self.dbcur.executemany(SET_MANY, settings_list)

	def get_memory_cache(self, setting_id):
		return get_property('fen.%s' % setting_id)

	def set_memory_cache(self, setting_id, setting_value):
		set_property('fen.%s' % setting_id, setting_value)

	def delete_memory_cache(self, setting_id):
		clear_property('fen.' % setting_id)

	def setting_info(self, setting_id):
		return [i for i in default_settings() if i[0] == setting_id][0]

	def clean_database(self):
		try:
			self.dbcur.execute('VACUUM')
			return True
		except: return False
	
	def clear_database(self):
		try:
			self.dbcur.execute(CLEAR_SETTINGS)
			self.dbcur.execute('VACUUM')
			return 'success'
		except: return 'failure'

	def _connect_database(self):
		self.dbcon = database.connect(settings_db, timeout=40.0, isolation_level=None)

	def _set_PRAGMAS(self):
		self.dbcur = self.dbcon.cursor()
		self.dbcur.execute('''PRAGMA synchronous = OFF''')
		self.dbcur.execute('''PRAGMA journal_mode = OFF''')

def default_settings():
	return [
('auto_start_fen', 'boolean', 'false'), ('auto_invoker_fix', 'boolean', 'false'), ('kodi_menu_cache', 'boolean', 'false'), ('limit_concurrent_threads', 'boolean', 'true'),
('max_threads', 'integer', '60'), ('addon_fanart', 'path', ''), ('addon_fanart.restore', 'string', '$ADDON[plugin.video.fen 32652]'),
('highlight_name', 'string', '[COLOR=FF008EB2]FF008EB2[/COLOR]'), ('use_skin_fonts', 'boolean', 'true'), ('use_custom_skins', 'boolean', 'true'),
('trakt.indicators_active', 'string', 'false'), ('watched_indicators', 'integer', '0'), ('trakt.sync_interval', 'integer', '30'), ('trakt.sync_refresh_widgets', 'boolean', 'false'),
('datetime.offset', 'integer', '0'), ('movie_download_directory', 'path', 'special://profile/addon_data/plugin.video.fen/Movies Downloads/'),
('tvshow_download_directory', 'path', 'special://profile/addon_data/plugin.video.fen/TV Show Downloads/'),
('premium_download_directory', 'path', 'special://profile/addon_data/plugin.video.fen/Premium Downloads/'),
('image_download_directory', 'path', 'special://profile/addon_data/plugin.video.fen/Image Downloads/'), ('extras.open_action', 'integer', '0'),
('extras.manage', 'string', '$ADDON[plugin.video.fen 32652]'), ('extras.button_choice', 'string', '$ADDON[plugin.video.fen 32652]'),
('extras.restore_default', 'string', '$ADDON[plugin.video.fen 32652]'), ('extras.enable_extra_ratings', 'boolean', 'true'),
('extras.enabled_ratings', 'string', 'Meta, Tom/Critic, Tom/User, IMDb, TMDb'), ('extras.enable_scrollbars', 'boolean', 'false'),
('extras.exclude_non_acting_roles', 'boolean', 'true'), ('extras.windowed_playback', 'boolean', 'false'), ('custom_context_main_menu', 'boolean', 'false'),
('custom_context_menu', 'boolean', 'false'), ('custom_info_dialog', 'boolean', 'false'), ('sort.progress', 'integer', '0'), ('sort.watched', 'integer', '0'),
('sort.collection', 'integer', '0'), ('sort.watchlist', 'integer', '0'), ('paginate.lists', 'integer', '0'), ('paginate.limit_addon', 'integer', '20'),
('paginate.limit_widgets', 'integer', '20'), ('paginate.jump_to', 'integer', '0'), ('ignore_articles', 'boolean', 'true'), ('show_specials', 'boolean', 'false'),
('use_season_title', 'boolean', 'false'), ('show_unaired', 'boolean', 'true'), ('show_unaired_watchlist', 'boolean', 'true'), ('include_year_in_title', 'integer', '0'),
('default_all_episodes', 'integer', '0'), ('single_ep_display', 'integer', '0'), ('single_ep_format', 'integer', '0'), ('tv_progress_location', 'integer', '0'),
('avoid_episode_spoilers', 'boolean', 'false'), ('trakt.calendar_sort_order', 'integer', '0'), ('trakt.calendar_previous_days', 'integer', '0'),
('trakt.calendar_future_days', 'integer', '7'), ('nextep.sort_type', 'integer', '0'), ('nextep.sort_order', 'integer', '0'), ('nextep.sort_airing_today_to_top', 'boolean', 'false'),
('nextep.include_airdate', 'boolean', 'false'), ('nextep.include_unaired', 'boolean', 'false'), ('nextep.include_unwatched', 'integer', '0'),
('widget_hide_watched', 'boolean', 'false'), ('widget_hide_next_page', 'boolean', 'false'), ('get_fanart_data', 'boolean', 'false'), ('fanarttv.default', 'boolean', 'false'),
('image_resolutions', 'integer', '2'), ('meta_language_display', 'string', 'English'), ('meta_mpaa_region_display', 'string', 'United States'),
('meta_use_year_in_search', 'boolean', 'false'), ('meta_filter', 'boolean', 'true'), ('trakt.user', 'string', ''), ('tmdb_api', 'string', 'b370b60447737762ca38457bd77579b3'),
('fanart_client_key', 'string', 'fa836e1c874ba95ab08a14ee88e05565'), ('omdb_api', 'string', ''), ('imdb_user', 'string', ''), ('imdb_lists.sort_type', 'integer', '0'),
('imdb_lists.sort_direction', 'integer', '0'), ('check_premium_account_status', 'boolean', 'false'), ('provider.external', 'boolean', 'false'),
('external_scraper.name', 'string', ''), ('rd.token', 'string', ''), ('rd.enabled', 'boolean', 'true'), ('rd.account_id', 'string', ''), ('rd.torrent.enabled', 'boolean', 'true'),
('rd.hoster.enabled', 'boolean', 'true'), ('store_resolved_torrent.real-debrid', 'integer', '0'), ('provider.rd_cloud', 'boolean', 'false'),
('rd_cloud.title_filter', 'boolean', 'true'), ('check.rd_cloud', 'boolean', 'false'), ('results.sort_rdcloud_first', 'boolean', 'true'), ('rd.priority', 'integer', '10'),
('pm.token', 'string', ''), ('pm.enabled', 'boolean', 'true'), ('pm.account_id', 'string', ''), ('pm.torrent.enabled', 'boolean', 'true'), ('pm.hoster.enabled', 'boolean', 'true'),
('store_resolved_torrent.premiumize.me', 'integer', '0'), ('provider.pm_cloud', 'boolean', 'false'), ('pm_cloud.title_filter', 'boolean', 'true'),
('check.pm_cloud', 'boolean', 'false'), ('results.sort_pmcloud_first', 'boolean', 'true'), ('pm.priority', 'integer', '10'), ('ad.token', 'string', ''),
('ad.enabled', 'boolean', 'true'), ('ad.account_id', 'string', ''), ('ad.torrent.enabled', 'boolean', 'true'), ('ad.hoster.enabled', 'boolean', 'true'),
('store_resolved_torrent.alldebrid', 'integer', '0'), ('provider.ad_cloud', 'boolean', 'false'), ('ad_cloud.title_filter', 'boolean', 'true'),
('check.ad_cloud', 'boolean', 'false'), ('results.sort_adcloud_first', 'boolean', 'true'), ('ad.priority', 'integer', '10'),
('provider.furk', 'boolean', 'false'), ('furk_login', 'string', ''), ('furk_password', 'string', ''), ('furk_api_key', 'string', ''), ('furk.title_filter', 'boolean', 'true'),
('check.furk', 'boolean', 'false'), ('fu.priority', 'integer', '6'), ('provider.easynews', 'boolean', 'false'), ('easynews_user', 'string', ''), ('easynews_password', 'string', ''),
('easynews.use_custom_farm', 'string', 'False'), ('easynews.server_name', 'string', 'Auto:443'), ('easynews.title_filter', 'boolean', 'true'),
('easynews.filter_lang', 'boolean', 'false'), ('easynews.lang_filters', 'string', 'eng'), ('check.easynews', 'boolean', 'false'), ('en.priority', 'integer', '7'),
('provider.folders', 'boolean', 'false'), ('folders.title_filter', 'boolean', 'true'), ('check.folders', 'boolean', 'false'), ('results.sort_folders_first', 'boolean', 'true'),
('results.folders_ignore_filters', 'boolean', 'false'), ('results.timeout', 'integer', '20'), ('results.list_format', 'string', 'List'), ('results.use_contrast', 'boolean', 'true'),
('search.enable.yearcheck', 'boolean', 'false'), ('search.finish.early', 'boolean', 'false'), ('torrent.display.uncached', 'boolean', 'false'),
('results.ignore_filter', 'integer', '0'), ('results.sort_order_display', 'string', '$ADDON[plugin.video.fen 32582]'), ('results.size_sort_direction', 'integer', '0'),
('results.filter_size_method', 'integer', '0'), ('results.size.auto', 'integer', '20'), ('results.size.manual', 'integer', '10000'), ('results.size.min_manual', 'integer', '0'),
('results.include.unknown.size', 'boolean', 'true'), ('include_prerelease_results', 'boolean', 'true'), ('include_3d_results', 'boolean', 'true'), ('filter_hevc', 'integer', '0'),
('filter_hevc.max_quality', 'string', '4K'), ('filter_hevc.max_autoplay_quality', 'string', '4K'), ('filter_hdr', 'integer', '0'), ('filter_dv', 'integer', '0'),
('filter_av1', 'integer', '0'), ('filter_audio', 'string', ''), ('highlight.type', 'integer', '1'), ('hoster.identify_name', 'string', '[COLOR=FF0166FF]FF0166FF[/COLOR]'),
('torrent.identify_name', 'string', '[COLOR=FFFF00FE]FFFF00FE[/COLOR]'), ('provider.rd_colour_name', 'string', '[COLOR=FF3C9900]FF3C9900[/COLOR]'),
('provider.pm_colour_name', 'string', 'FFFF3300'), ('provider.ad_colour_name', 'string', '[COLOR=FFE6B800]FFE6B800[/COLOR]'),
('provider.furk_colour_name', 'string', '[COLOR=FFE6002E]FFE6002E[/COLOR]'), ('provider.easynews_colour_name', 'string', '[COLOR=FF00B3B2]FF00B3B2[/COLOR]'),
('provider.debrid_cloud_colour_name', 'string', '[COLOR=FF7A01CC]FF7A01CC[/COLOR]'), ('provider.folders_colour_name', 'string', '[COLOR=FFB36B00]FFB36B00[/COLOR]'),
('scraper_4k_highlight_name', 'string', '[COLOR=FFFF00FE]FFFF00FE[/COLOR]'), ('scraper_1080p_highlight_name', 'string', '[COLOR=FFE6B800]FFE6B800[/COLOR]'),
('scraper_720p_highlight_name', 'string', '[COLOR=FF3C9900]FF3C9900[/COLOR]'), ('scraper_SD_highlight_name', 'string', '[COLOR=FF0166FF]FF0166FF[/COLOR]'),
('scraper_single_highlight_name', 'string', '[COLOR=FF008EB2]FF008EB2[/COLOR]'), ('scraper_flag_identify_colour_name', 'string', '[COLOR=FF7C7C7C]FF7C7C7C[/COLOR]'),
('scraper_result_identify_colour_name', 'string', '[COLOR=FFFFFFFF]FFFFFFFF[/COLOR]'), ('auto_play_movie', 'boolean', 'false'),
('results_quality_movie', 'string', 'SD, 720p, 1080p, 4K'), ('autoplay_quality_movie', 'string', 'SD, 720p, 1080p, 4K'), ('auto_resume_movie', 'integer', '0'),
('auto_play_episode', 'boolean', 'false'), ('results_quality_episode', 'string', 'SD, 720p, 1080p, 4K'), ('autoplay_quality_episode', 'string', 'SD, 720p, 1080p, 4K'),
('autoplay_next_episode', 'boolean', 'false'), ('autoplay_alert_method', 'integer', '0'), ('autoplay_default_action', 'integer', '0'),
('autoplay_next_window_percentage', 'integer', '95'), ('autoplay_use_chapters', 'boolean', 'true'), ('autoscrape_next_episode', 'boolean', 'false'),
('autoscrape_next_window_percentage', 'integer', '95'), ('autoscrape_use_chapters', 'boolean', 'true'), ('auto_resume_episode', 'integer', '0'),
('playback.resume_percent', 'integer', '5'), ('playback.watched_percent', 'integer', '90'), ('playback.limit_resolve', 'boolean', 'false'),
('playback.disable_content_lookup', 'boolean', 'false'), ('playback.monitor_success', 'boolean', 'true'), ('playback.pause_start', 'integer', '1500'),
('playback.easynews_max_retries', 'integer', '1'), ('playback.volumecheck_enabled', 'boolean', 'false'), ('playback.volumecheck_percent', 'integer', '50'),
('subtitles.subs_action', 'integer', '2'), ('subtitles.language_primary', 'string', 'eng'), ('subtitles.language_secondary', 'string', 'None'),
('subtitles.auto_enable', 'boolean', 'true'), ('tools.make_fen_work', 'boolean', 'false'), ('external_scraper.module', 'string', ''), ('trakt.expires', 'string', '0'),
('trakt.refresh', 'string', '0'), ('trakt.token', 'string', '0'), ('rd.client_id', 'string', ''), ('rd.refresh', 'string', ''), ('rd.secret', 'string', ''),
('meta_language', 'string', 'en'), ('meta_mpaa_region', 'string', 'US'), ('results.sort_order', 'string', '1'), ('database.maintenance.due', 'string', '0'),
('reuse_language_invoker', 'string', 'true'), ('folder1.display_name', 'string', 'Folder 1'), ('folder1.movies_directory', 'string', 'None'),
('folder1.tv_shows_directory', 'string', 'None'), ('folder2.display_name', 'string', 'Folder 2'), ('folder2.movies_directory', 'string', 'None'),
('folder2.tv_shows_directory', 'string', 'None'), ('folder3.display_name', 'string', 'Folder 3'), ('folder3.movies_directory', 'string', 'None'),
('folder3.tv_shows_directory', 'string', 'None'), ('folder4.display_name', 'string', 'Folder 4'), ('folder4.movies_directory', 'string', 'None'),
('folder4.tv_shows_directory', 'string', 'None'), ('folder5.display_name', 'string', 'Folder 5'), ('folder5.movies_directory', 'string', 'None'),
('folder5.tv_shows_directory', 'string', 'None'), ('easynews.farm', 'string', 'auto'), ('easynews.port', 'string', '443'), ('version_number', 'string', '0'),
('dummy_setting', 'string', 'foo'), ('extras.enabled', 'string', '2000,2050,2051,2052,2053,2054,2055,2056,2057,2058,2059,2060,2061,2062,2063'), ('highlight', 'string', 'FF12A0C7'),
('provider.furk_colour', 'string', 'FFE6002E'), ('provider.easynews_colour', 'string', 'FF00B3B2'), ('provider.debrid_cloud_colour', 'string', 'FF7A01CC'),
('provider.folders_colour', 'string', 'FFB36B00'), ('hoster.identify', 'string', 'FF0166FF'), ('torrent.identify', 'string', 'FFFF00FE'), ('provider.rd_colour', 'string', 'FF3C9900'),
('provider.pm_colour', 'string', 'FFFF3300'), ('provider.ad_colour', 'string', 'FFE6B800'), ('scraper_4k_highlight', 'string', 'FFFF00FE'),
('scraper_1080p_highlight', 'string', 'FFE6B800'), ('scraper_720p_highlight', 'string', 'FF3C9900'), ('scraper_SD_highlight', 'string', 'FF0166FF'),
('scraper_single_highlight', 'string', 'FF008EB2'), ('scraper_flag_identify_colour', 'string', 'FF7C7C7C'), ('scraper_result_identify_colour', 'string', 'FFFFFFFF'),
('extras.tvshow.button10', 'string', 'tvshow_browse'), ('extras.tvshow.button11', 'string', 'show_trailers'), ('extras.tvshow.button12', 'string', 'show_trakt_manager'),
('extras.tvshow.button13', 'string', 'show_images'), ('extras.tvshow.button14', 'string', 'show_extrainfo'), ('extras.tvshow.button15', 'string', 'show_genres'),
('extras.tvshow.button16', 'string', 'play_nextep'), ('extras.tvshow.button17', 'string', 'show_options'), ('extras.movie.button10', 'string', 'movies_play'),
('extras.movie.button11', 'string', 'show_trailers'), ('extras.movie.button12', 'string', 'show_trakt_manager'), ('extras.movie.button13', 'string', 'show_images'),
('extras.movie.button14', 'string', 'show_extrainfo'), ('extras.movie.button15', 'string', 'show_genres'), ('extras.movie.button16', 'string', 'show_director'),
('extras.movie.button17', 'string', 'show_options'), ('first_use', 'string', 'false'), ('view.main', 'string', '55'), ('view.movies', 'string', '500'),
('view.tvshows', 'string', '500'), ('view.seasons', 'string', '55'), ('view.episodes', 'string', '55'), ('view.episodes_single', 'string', '55'), ('view.premium', 'string', '55'),
]

def setting_labels():
	return {

	}

def convert_settings():
	from modules.kodi_utils import mdParse, user_settings
	from modules.kodi_utils import logger
	try:
		settings_data = mdParse(user_settings).getElementsByTagName('setting')
		current_user_settings = [(item.getAttribute('id'), item.firstChild.data if item.firstChild and item.firstChild.data is not None else '') for item in settings_data]
	except: current_user_settings = []
	logger('current_user_settings', len(current_user_settings))
	insert_list = []
	insert_list_append = insert_list.append
	for item in default_settings():
		setting_id = item[0]
		if 'amble' in setting_id: continue
		setting_type = item[1]
		setting_default = item[2]
		if current_user_settings:
			try: setting_value = [i[1] for i in current_user_settings if i[0] == setting_id][0]
			except: setting_value = setting_default
		else: setting_value = setting_default
		insert_list_append((setting_id, setting_type, setting_default, setting_value))
	logger('def_settings_len', len(default_settings()))
	logger('insert_list', len(insert_list))
	test_default = [i[0] for i in default_settings()]
	# logger('test_default', test_default)
	remaining_settings = [i for i in current_user_settings if not i[0] in test_default]
	logger('remaining settings', len(remaining_settings))
	SettingsCache().set_many(insert_list)


def check_settings():
	# if not SettingsCache().get_all(): convert_settings()
	convert_settings()
