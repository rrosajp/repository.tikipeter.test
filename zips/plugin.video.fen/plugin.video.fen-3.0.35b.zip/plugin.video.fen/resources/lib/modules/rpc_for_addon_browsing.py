
from modules.kodi_utils import json, execute_JSON, dialog, execute_builtin, get_property, set_property, getCurrentWindowId, Thread, sleep
from modules.kodi_utils import logger

def get_plugin_path(skin_setting, library_type='video', info=('', None)):
	label, directory = info[0].replace(' >>', '').replace('[B]', '').replace('[/B]', ''), info[1]
	if not directory:
		folders, directory = [('Clear Current Path', 'clear_path')], 'addons://sources/video'if library_type.startswith('video') else 'addons://sources/audio'
	else: folders = [('Use [B]%s[/B] As Path' % label, 'set_folder_path')]
	result = files_get_directory(directory)
	if result:
		folders.extend([('%s >>' % i['label'], i['file']) for i in result if i['file'].startswith('plugin://')])
		choice = dialog.select('Choose Path', [i[0] for i in folders])
		if choice == -1: return None
		choice = folders[choice]
		if choice[1] == 'set_folder_path':
			label = dialog.input('FEN', defaultt=label)
			if not label: return
			execute_builtin('Skin.SetString(%s.path, %s)' % (skin_setting, directory))
			execute_builtin('Skin.SetString(%s.header, %s)' % (skin_setting, label))
		elif choice[1] == 'clear_path':
			execute_builtin('Skin.Reset(%s.path, %s)' % (skin_setting, ''))
			execute_builtin('Skin.Reset(%s.header, %s)' % (skin_setting, ''))
			Thread(target=reload_skin).start()
		else: return get_plugin_path(skin_setting, library_type, choice)
	try: dialog.close()
	except: pass

def files_get_directory(directory, properties=['title', 'file', 'thumbnail']):
	command = {'jsonrpc': '2.0', 'id': 0, 'method': 'Files.GetDirectory', 'params': {'directory': directory, 'media': 'files', 'properties': properties}}
	result = get_jsonrpc(command)
	return result.get('files', None)

def get_jsonrpc(request):
	response = execute_JSON(json.dumps(request))
	result = json.loads(response)
	return result.get('result', None)

def reload_skin():
	if get_property('fen.clear_path_refresh') == 'true': return
	set_property('fen.clear_path_refresh', 'true')
	while getCurrentWindowId() == 10035: sleep(500)
	set_property('fen.clear_path_refresh', '')
	sleep(100)
	execute_builtin('ReloadSkin()')
