# -*- coding: utf-8 -*-
from modules import kodi_utils
logger = kodi_utils.logger

json, ls, numeric_input = kodi_utils.json, kodi_utils.local_string, kodi_utils.numeric_input
get_setting, set_setting, get_property, set_property = kodi_utils.get_setting, kodi_utils.set_setting, kodi_utils.get_property, kodi_utils.set_property
dialog, ok_dialog, select_dialog = kodi_utils.dialog, kodi_utils.ok_dialog, kodi_utils.select_dialog

boolean_dict = {'true': 'false', 'false': 'true'}

def set_boolean(params):
	setting = params['setting']
	current_value = get_setting(setting)
	set_setting(setting, boolean_dict[current_value])
	set_property('fen.%s' % setting, boolean_dict[current_value])

def set_numeric(params):
	_get = params.get
	min_value, max_value = int(_get('min_value', '0')), int(_get('max_value', '1000000'))
	negative_included = any((n < 0 for n in [min_value, max_value]))
	new_value = dialog.input('Range [B]%s - %s[/B].' % (min_value, max_value), type=numeric_input)
	if not new_value: return
	if negative_included and not new_value == '0':
		multiplier_values = [('Positive(+)', 1), ('Negative(-)', -1)]
		list_items = [{'line1': ls(item[0])} for item in multiplier_values]
		kwargs = {'items': json.dumps(list_items), 'narrow_window': 'true'}
		multiplier = select_dialog(multiplier_values, **kwargs)
		if multiplier: new_value = str(int(float(new_value) * multiplier[1]))
	if int(new_value) < min_value or int(new_value) > max_value:
		ok_dialog(text='Please Choose Between the Range [B]%s - %s[/B].' % (min_value, max_value))
		return set_numeric(params)
	set_setting(params['setting'], new_value)
	set_property('fen.%s' % params['setting'], new_value)

def set_path(params):
	browse_mode = int(params.get('browse_mode', '0'))
	current_value = get_setting(params.get('setting', ''))
	new_value = dialog.browse(browse_mode, '', '', defaultt=current_value)
	if not new_value: return
	set_setting(params['setting'], new_value)
	set_property('fen.%s' % params['setting'], new_value)

def set_from_list_integer(params):
	setting, setting_name = params['setting'], params['setting_name']
	settings_list = [(i, str(c)) for c, i in enumerate(params['settings_list'].split('-'))]
	list_items = [{'line1': ls(item[0])} for item in settings_list]
	kwargs = {'items': json.dumps(list_items), 'narrow_window': 'true'}
	new_value = select_dialog(settings_list, **kwargs)
	if new_value:
		setting_name_value, setting_value = ls(new_value[0]), new_value[1]
		set_setting(setting_name, setting_name_value)
		set_setting(setting, setting_value)
		set_property('fen.%s' % setting_name, setting_name_value)
		set_property('fen.%s' % setting, setting_value)
