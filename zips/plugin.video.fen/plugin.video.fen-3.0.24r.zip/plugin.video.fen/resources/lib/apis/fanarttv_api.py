# -*- coding: utf-8 -*-
from modules.dom_parser import parseDOM
from modules.kodi_utils import make_session, fanarttv_default_api
# from modules.kodi_utils import logger

# Code snippets from nixgates. Thankyou.
base_url = 'https://webservice.fanart.tv/v3/%s/%s'
blank_image_values = ('00', '', 'None')
default_fanart_meta = {'poster2': '', 'fanart2': '', 'clearlogo2': '', 'banner': '', 'clearart': '', 'landscape': '', 'discart': '', 'keyart': '', 'fanart_added': True}
default_fanart_nometa = {'poster2': '', 'fanart2': '', 'clearlogo2': '', 'banner': '', 'clearart': '', 'landscape': '', 'discart': '', 'keyart': '', 'fanart_added': False}
default_all_fanart_images = {'poster': [], 'fanart': [], 'clearlogo': [], 'banner': [], 'clearart': [], 'landscape': [], 'discart': [], 'keyart': []}
session = make_session('https://webservice.fanart.tv')

def get(media_type, language, media_id, client_key):
	if not media_id: return default_fanart_meta, default_all_fanart_images
	query = base_url % (media_type, media_id)
	headers = {'client-key': client_key, 'api-key': fanarttv_default_api}
	try: art = session.get(query, headers=headers, timeout=20.0).json()
	except: art = None
	if art == None or 'error_message' in art: return default_fanart_meta, default_all_fanart_images
	art_get = art.get
	if media_type == 'movies':
		poster = art_get('movieposter', [])
		fanart = art_get('moviebackground', [])
		clearlogo = art_get('hdmovielogo', []) + art_get('movielogo', [])
		banner = art_get('moviebanner', [])
		clearart = art_get('movieart', []) + art_get('hdmovieclearart', [])
		landscape = art_get('moviethumb', [])
		discart = art_get('moviedisc', [])
		keyart = [i for i in poster if i['lang'] in blank_image_values]
		fanart_data = {'poster2': parse_art(poster, language),
						'fanart2': parse_art(fanart, language),
						'clearlogo2': parse_art(clearlogo, language),
						'banner': parse_art(banner, language),
						'clearart': parse_art(clearart, language),
						'landscape': parse_art(landscape, language),
						'discart': parse_art(discart, language),
						'keyart': parse_art(poster, 'keyart'),
						'fanart_added': True}
		discart, keyart = [i['url'] for i in discart], [i['url'] for i in keyart]
	else:
		# seasonposter - {'id': '39127', 'url': 'https://assets.fanart.tv/fanart/tv/82066/seasonposter/fringe-53514a41e5edc.jpg', 'lang': 'en', 'likes': '3', 'season': '1'}
		# seasonbanner - {'id': '39223', 'url': 'https://assets.fanart.tv/fanart/tv/82066/seasonbanner/fringe-53528d8d87c3f.jpg', 'lang': 'en', 'likes': '1', 'season': '1'}
		# seasonthumb -  {'id': '21706', 'url': 'https://assets.fanart.tv/fanart/tv/82066/seasonthumb/fringe-5070564bf2bcd.jpg', 'lang': 'en', 'likes': '3', 'season': '1'}
		poster = art_get('tvposter', [])
		fanart = art_get('showbackground', [])
		clearlogo = art_get('hdtvlogo', []) + art_get('clearlogo', [])
		banner = art_get('tvbanner', [])
		clearart = art_get('clearart', []) + art_get('hdclearart', [])
		landscape = art_get('tvthumb', [])
		fanart_data = {'poster2': parse_art(poster, language),
						'fanart2': parse_art(fanart, language),
						'clearlogo2': parse_art(clearlogo, language),
						'banner': parse_art(banner, language),
						'clearart': parse_art(clearart, language),
						'landscape': parse_art(landscape, language),
						'discart': '',
						'keyart': '',
						'fanart_added': True}
		discart, keyart = [], []
	all_fanart_images = {'poster': [i['url'] for i in poster],
						'fanart': [i['url'] for i in fanart],
						'clearlogo': [i['url'] for i in clearlogo],
						'banner': [i['url'] for i in banner],
						'clearart': [i['url'] for i in clearart],
						'landscape': [i['url'] for i in landscape],
						'discart': discart,
						'keyart': keyart}
	return fanart_data, all_fanart_images

def parse_art(art, language):
	if not art: return ''
	try:
		if language == 'keyart':
			result = [i for i in art if i['lang'] in blank_image_values]
		else:
			result = [i for i in art if i['lang'] == language]
			if not result: result = [i for i in art if i['lang'] in blank_image_values]
			if not result and language != 'en': result = [i for i in art if i['lang'] == 'en']
		result = result[0]['url']
	except: result = ''
	return result
