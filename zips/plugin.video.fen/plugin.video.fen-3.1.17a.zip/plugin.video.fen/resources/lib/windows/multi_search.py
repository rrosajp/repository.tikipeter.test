# -*- coding: utf-8 -*-
from windows import BaseDialog
from apis import tmdb_api, imdb_api, trakt_api
# from indexers.movies import Movies
from indexers.tvshows import TVShows
from modules.settings import get_resolution
from modules.kodi_utils import Thread, addon_fanart, empty_poster, local_string as ls
from modules.kodi_utils import logger

class MultiSearch(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.window_id = 2000
		self.set_starting_constants()
		self.query = 'Secret Invasion'

	def run(self):
		self.doModal()
		self.clearProperties()

	def make_tmdb_movies(self):
		self.tmdb_movies = []
		try:
			results = {'list': [(count, item['id']) for count, item in enumerate(tmdb_api.tmdb_movies_search(self.query, 1)['results'], 1)], 'custom_order': 'true'}
			self._add_to_list(Movies, results, self.tmdb_movies)
			self.setProperty('tmdb_movies.number', '(x%02d)' % len(item_list))
			self.item_action_dict[_id] = 'tmdb_movies'
			self.add_items(_id, item_list)
		except: pass

	def make_tmdb_tvshows(self):
		self.tmdb_tvshows = []
		try:
			results = {'list': [(count, item['id']) for count, item in enumerate(tmdb_api.tmdb_tv_search(self.query, 1)['results'], 1)], 'custom_order': 'true'}
			self._add_to_list(TVShows, results, self.tmdb_tvshows)
			self.setProperty('tmdb_tvshows.number', '(x%02d)' % len(item_list))
			self.item_action_dict[_id] = 'tmdb_tvshows'
			self.add_items(_id, item_list)
		except: pass

	def _add_to_list(self, function, _list, item_list):
		item_list.extend(function(_list).worker())


	def set_starting_constants(self):
		self.item_action_dict = {}
		resolutions = get_resolution()
		self.poster_resolution = resolutions['poster']
		self.fanart_resolution = resolutions['fanart']
