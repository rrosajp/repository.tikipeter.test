
from modules.kodi_utils import json, execute_JSON, dialog, execute_builtin, get_property, set_property, getCurrentWindowId, Thread, sleep, numeric_input
# from modules.kodi_utils import logger

def get_plugin_path(skin_setting, library_type='video', info=('', None)):
	label, directory = info[0].replace(' >>', '').replace('[B]', '').replace('[/B]', ''), info[1]
	if not directory:
		folders, directory = [('Clear Current Path', 'clear_path')], 'addons://sources/video'if library_type.startswith('video') else 'addons://sources/audio'
	else: folders = [('Use [B]%s[/B] As Path' % label, 'set_folder_path')]
	result = files_get_directory(directory)
	if result:
		folders.extend([('%s >>' % i['label'], i['file']) for i in result if i['file'].startswith('plugin://')])
		choice = dialog.select('Choose Path', [i[0] for i in folders])
		if choice == -1: return None
		choice = folders[choice]
		if choice[1] == 'set_folder_path':
			label = dialog.input('Widget Label', defaultt=label)
			if not label: return
			types = ['Poster', 'Fanart']
			choice = dialog.select('Choose Type', types)
			type_choice = types[choice]
			limit = dialog.input('Widget Limit (0 or blank for no limit))', type=numeric_input)
			limit_used = limit not in ('', '0', -1)
			setting_label = '%s | %s' % (label, type_choice)
			if limit_used:
				setting_label += ' | x%s' % limit
				execute_builtin('Skin.SetString(%s.limit, %s)' % (skin_setting, limit))
			execute_builtin('Skin.SetString(%s.setting_label, %s)' % (skin_setting, setting_label))
			execute_builtin('Skin.SetString(%s.path, %s)' % (skin_setting, directory))
			execute_builtin('Skin.SetString(%s.header, %s)' % (skin_setting, label))
			execute_builtin('Skin.SetString(%s.type, %s)' % (skin_setting, type_choice))
		elif choice[1] == 'clear_path': clear_skin_settings(skin_setting)
		else: return get_plugin_path(skin_setting, library_type, choice)
	try: dialog.close()
	except: pass

def files_get_directory(directory, properties=['title', 'file', 'thumbnail']):
	command = {'jsonrpc': '2.0', 'id': 0, 'method': 'Files.GetDirectory', 'params': {'directory': directory, 'media': 'files', 'properties': properties}}
	result = get_jsonrpc(command)
	return result.get('files', None)

def get_jsonrpc(request):
	response = execute_JSON(json.dumps(request))
	result = json.loads(response)
	return result.get('result', None)

def clear_skin_settings(skin_setting):
	execute_builtin('Skin.Reset(%s.setting_label, %s)' % (skin_setting, ''))
	execute_builtin('Skin.Reset(%s.path, %s)' % (skin_setting, ''))
	execute_builtin('Skin.Reset(%s.header, %s)' % (skin_setting, ''))
	execute_builtin('Skin.Reset(%s.type, %s)' % (skin_setting, ''))
	execute_builtin('Skin.Reset(%s.limit, %s)' % (skin_setting, ''))
	Thread(target=reload_skin).start()

def reload_skin():
	if get_property('fen.clear_path_refresh') == 'true': return
	set_property('fen.clear_path_refresh', 'true')
	while getCurrentWindowId() == 10035: sleep(500)
	set_property('fen.clear_path_refresh', '')
	sleep(100)
	execute_builtin('ReloadSkin()')
